/*
 * server.js: backend website "24 Chapters of You"
 *
 * Tugasnya:
 *   1. Memeriksa login (kredensial ada di .env, password berupa hash bcrypt).
 *   2. Menyajikan website. Selain halaman login, semua file (foto, musik,
 *      config.js) hanya bisa dibuka setelah login.
 *   3. Menerima jawaban Cerin, memeriksanya, lalu menambahkannya ke
 *      data/answers.txt.
 *
 * Konten website (slide, pertanyaan, foto) ada di public/config.js,
 * jadi biasanya file ini tidak perlu diubah.
 */

const path = require("path");
const fs = require("fs");
const crypto = require("crypto");

require("dotenv").config({ path: path.join(__dirname, ".env"), quiet: true });

const express = require("express");
const session = require("express-session");
const MemoryStore = require("memorystore")(session);
const helmet = require("helmet");
const { rateLimit } = require("express-rate-limit");
const bcrypt = require("bcrypt");

/* ------------------------------------------------------------------ */
/* Pengaturan                                                          */
/* ------------------------------------------------------------------ */

const PORT = Number(process.env.PORT) || 3000;
const IS_PRODUCTION = process.env.NODE_ENV === "production";
const TIMEZONE = process.env.TIMEZONE || "Asia/Jakarta";
const USERNAME = process.env.LOGIN_USERNAME;
const PASSWORD_HASH = process.env.LOGIN_PASSWORD_HASH;
const SESSION_SECRET = process.env.SESSION_SECRET;

const PUBLIC_DIR = path.join(__dirname, "public");
const ANSWERS_FILE = path.join(__dirname, "data", "answers.txt");
const SESSION_LIFETIME_MS = 7 * 24 * 60 * 60 * 1000; // 7 hari

const WRONG_LOGIN_MESSAGE = "username atau password salah dek";
const GENERIC_ERROR_MESSAGE = "Ada yang nggak beres di server. Coba lagi sebentar ya.";

function stopWithMessage(message) {
  console.error(`\n[Tidak bisa mulai] ${message}\n`);
  process.exit(1);
}

if (!USERNAME || !PASSWORD_HASH) {
  stopWithMessage("LOGIN_USERNAME atau LOGIN_PASSWORD_HASH belum ada di .env. Jalankan: npm run set-login");
}
if (!/^\$2[aby]\$\d{2}\$.{53}$/.test(PASSWORD_HASH)) {
  stopWithMessage("LOGIN_PASSWORD_HASH bukan hash bcrypt yang valid. Jalankan: npm run set-login");
}
if (!SESSION_SECRET || SESSION_SECRET.length < 32) {
  stopWithMessage("SESSION_SECRET di .env harus minimal 32 karakter. Jalankan: npm run set-login");
}

/* Daftar pertanyaan dibaca dari file yang sama dengan frontend, supaya
   server tahu pertanyaan mana yang sah dan apa saja pilihan jawabannya. */
let questionById;
try {
  const { questions } = require("./public/config.js");
  questionById = new Map();
  for (const question of questions) {
    if (questionById.has(question.id)) throw new Error(`id pertanyaan "${question.id}" dipakai dua kali`);
    questionById.set(question.id, question);
  }
} catch (error) {
  stopWithMessage(`public/config.js bermasalah: ${error.message}`);
}

/* ------------------------------------------------------------------ */
/* Aplikasi dan security headers                                       */
/* ------------------------------------------------------------------ */

const app = express();
app.disable("x-powered-by");

// Jumlah reverse proxy di depan app (mis. Nginx/Caddy/platform hosting).
// Dibutuhkan agar cookie Secure dan rate limit membaca IP asli.
app.set("trust proxy", process.env.TRUST_PROXY !== undefined ? Number(process.env.TRUST_PROXY) || 0 : IS_PRODUCTION ? 1 : 0);

app.use(
  helmet({
    contentSecurityPolicy: {
      useDefaults: false,
      directives: {
        defaultSrc: ["'self'"],
        scriptSrc: ["'self'"],
        styleSrc: ["'self'"],
        imgSrc: ["'self'", "data:"],
        fontSrc: ["'self'"],
        mediaSrc: ["'self'"],
        connectSrc: ["'self'"],
        objectSrc: ["'none'"],
        baseUri: ["'self'"],
        formAction: ["'self'"],
        frameAncestors: ["'none'"],
        ...(IS_PRODUCTION ? { upgradeInsecureRequests: [] } : {}),
      },
    },
    strictTransportSecurity: IS_PRODUCTION,
    // Header ini hanya berlaku di HTTPS, jadi dimatikan saat uji di http://
    crossOriginOpenerPolicy: IS_PRODUCTION,
    originAgentCluster: IS_PRODUCTION,
  })
);

// Website pribadi: minta mesin pencari untuk tidak mengindeks.
app.use((req, res, next) => {
  res.setHeader("X-Robots-Tag", "noindex, nofollow");
  next();
});

app.use(
  session({
    name: "cerin.sid",
    secret: SESSION_SECRET,
    store: new MemoryStore({ checkPeriod: 60 * 60 * 1000, max: 5000, ttl: SESSION_LIFETIME_MS }),
    resave: false,
    saveUninitialized: false,
    rolling: true,
    cookie: {
      httpOnly: true,
      sameSite: "lax",
      secure: IS_PRODUCTION, // cookie hanya dikirim lewat HTTPS saat production
      maxAge: SESSION_LIFETIME_MS,
    },
  })
);

/* ------------------------------------------------------------------ */
/* Pembatas dan pelindung API                                          */
/* ------------------------------------------------------------------ */

const apiLimiter = rateLimit({
  windowMs: 60 * 1000,
  limit: 240,
  standardHeaders: "draft-7",
  legacyHeaders: false,
  message: { error: "Pelan-pelan dek, coba lagi sebentar ya." },
});

const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 10,
  skipSuccessfulRequests: true, // hanya percobaan yang gagal yang dihitung
  standardHeaders: "draft-7",
  legacyHeaders: false,
  message: { error: "Terlalu banyak percobaan, dek. Coba lagi sekitar 15 menit lagi ya." },
});

const answerLimiter = rateLimit({
  windowMs: 60 * 1000,
  limit: 40,
  standardHeaders: "draft-7",
  legacyHeaders: false,
  message: { error: "Pelan-pelan dek, coba kirim lagi sebentar ya." },
});

const api = express.Router();
api.use((req, res, next) => {
  res.setHeader("Cache-Control", "no-store");
  next();
});
api.use(apiLimiter);
api.use(express.json({ limit: "10kb" }));

function isSameText(a, b) {
  const hashOf = (text) => crypto.createHash("sha256").update(String(text)).digest();
  return crypto.timingSafeEqual(hashOf(a), hashOf(b));
}

function getCsrfToken(req) {
  if (!req.session.csrfToken) req.session.csrfToken = crypto.randomBytes(32).toString("hex");
  return req.session.csrfToken;
}

function requireCsrf(req, res, next) {
  const sent = req.get("X-CSRF-Token");
  const expected = req.session.csrfToken;
  if (typeof sent !== "string" || !expected || !isSameText(sent, expected)) {
    return res.status(403).json({ error: "Sesi perlu disegarkan. Coba lagi ya." });
  }
  next();
}

function requireLogin(req, res, next) {
  if (req.session.authenticated === true) return next();
  res.status(401).json({ error: "Login dulu ya, dek." });
}

/* ------------------------------------------------------------------ */
/* Login dan sesi                                                      */
/* ------------------------------------------------------------------ */

// Hash cadangan: bcrypt tetap dijalankan walau username salah, sehingga lama
// respons tidak membocorkan apakah username-nya benar.
const DUMMY_HASH = bcrypt.hashSync(crypto.randomBytes(24).toString("hex"), 12);

api.get("/session", (req, res) => {
  res.json({ authenticated: req.session.authenticated === true, csrfToken: getCsrfToken(req) });
});

api.post("/login", loginLimiter, requireCsrf, async (req, res, next) => {
  try {
    const { username, password } = req.body || {};
    const validShape =
      typeof username === "string" && typeof password === "string" &&
      username.length > 0 && username.length <= 128 &&
      password.length > 0 && password.length <= 128;

    const usernameMatches = validShape && isSameText(username, USERNAME);
    const passwordMatches = await bcrypt.compare(
      validShape ? password : "",
      usernameMatches ? PASSWORD_HASH : DUMMY_HASH
    );

    if (!usernameMatches || !passwordMatches) {
      return res.status(401).json({ error: WRONG_LOGIN_MESSAGE });
    }

    // ID sesi diganti setelah login untuk mencegah session fixation.
    req.session.regenerate((regenerateError) => {
      if (regenerateError) return next(regenerateError);
      req.session.authenticated = true;
      const csrfToken = getCsrfToken(req);
      req.session.save((saveError) => {
        if (saveError) return next(saveError);
        res.json({ ok: true, csrfToken });
      });
    });
  } catch (error) {
    next(error);
  }
});

api.post("/logout", requireLogin, requireCsrf, (req, res, next) => {
  req.session.destroy((error) => {
    if (error) return next(error);
    res.clearCookie("cerin.sid");
    res.json({ ok: true });
  });
});

/* ------------------------------------------------------------------ */
/* Menyimpan jawaban ke data/answers.txt                               */
/* ------------------------------------------------------------------ */

const MONTHS_ID = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"];
const DEFAULT_MAX_LENGTH = { text: 200, textarea: 2000, date: 100, radio: 200 };

function cleanText(value) {
  return value
    .normalize("NFC")
    .replace(/\r\n?/g, "\n")
    // Buang karakter kontrol dan pembalik arah teks, tapi biarkan baris baru.
    .replace(/[\u0000-\u0009\u000B-\u001F\u007F-\u009F‪-‮⁦-⁩]/g, "")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

function optionLabel(option) {
  return typeof option === "string" ? option : option.label;
}

/** Mengembalikan { answer } jika valid, atau { error } jika tidak. */
function validateAnswer(question, rawAnswer) {
  if (typeof rawAnswer !== "string") return { error: "Jawabannya belum terbaca, dek." };
  // Batas kasar sebelum dibersihkan, supaya input raksasa langsung ditolak.
  if (rawAnswer.length > 8000) return { error: "Jawabannya kepanjangan, dek." };

  const answer = cleanText(rawAnswer);
  if (!answer) return { error: "Diisi dulu dong, dek." };

  const maxLength = question.maxLength || DEFAULT_MAX_LENGTH[question.type] || 200;
  if (answer.length > maxLength) return { error: "Jawabannya kepanjangan, dek." };

  if (question.type === "radio") {
    const isOption = question.options.some((option) => optionLabel(option) === answer);
    return isOption ? { answer } : { error: "Pilih salah satu dari yang ada ya, dek." };
  }

  if (question.maxWords && answer.split(/\s+/).length > question.maxWords) {
    return { error: "Satu kata aja, dek." };
  }

  if (question.type === "date") {
    const iso = answer.match(/^(\d{4})-(\d{2})-(\d{2})$/);
    if (iso) {
      const [year, month, day] = iso.slice(1).map(Number);
      const parsed = new Date(Date.UTC(year, month - 1, day));
      if (parsed.getUTCMonth() !== month - 1 || parsed.getUTCDate() !== day) {
        return { error: "Tanggalnya kayaknya salah, dek." };
      }
      return { answer: `${day} ${MONTHS_ID[month - 1]} ${year}` };
    }
  }

  return { answer };
}

function formatNow() {
  const parts = (timeZone) =>
    new Intl.DateTimeFormat("sv-SE", { timeZone, dateStyle: "short", timeStyle: "medium" }).format(new Date());
  try {
    return { stamp: parts(TIMEZONE), zone: TIMEZONE };
  } catch {
    return { stamp: parts("UTC"), zone: "UTC" };
  }
}

const LINE = "================================";
const FILE_HEADER = `${LINE}\nCERINOVA 24TH BIRTHDAY ANSWERS\n${LINE}\n\n`;

function formatEntry(question, answer) {
  const { stamp, zone } = formatNow();
  // Baris lanjutan diberi indentasi, sehingga isi jawaban tidak bisa meniru
  // baris "Question ID:" atau garis pemisah.
  const safeAnswer = answer.replace(/\n/g, "\n        ");
  return (
    `Date: ${stamp.slice(0, 10)}\n` +
    `Timestamp: ${stamp} (${zone})\n\n` +
    `Question ID: ${question.id}\n` +
    `Question: ${question.title}\n` +
    `Answer: ${safeAnswer}\n\n` +
    `${LINE}\n\n`
  );
}

// Antrean: jawaban ditulis satu per satu agar tidak saling bertabrakan.
let writeQueue = Promise.resolve();

function appendAnswer(question, answer) {
  const job = writeQueue.then(async () => {
    await fs.promises.mkdir(path.dirname(ANSWERS_FILE), { recursive: true });
    let isEmpty = true;
    try {
      isEmpty = (await fs.promises.stat(ANSWERS_FILE)).size === 0;
    } catch (error) {
      if (error.code !== "ENOENT") throw error;
    }
    const text = (isEmpty ? FILE_HEADER : "") + formatEntry(question, answer);
    // flush: data benar-benar ditulis ke disk sebelum Cerin diberi tahu "tersimpan".
    await fs.promises.appendFile(ANSWERS_FILE, text, { encoding: "utf8", flush: true });
  });
  writeQueue = job.catch(() => {});
  return job;
}

api.post("/answers", requireLogin, answerLimiter, requireCsrf, async (req, res, next) => {
  try {
    const { questionId, answer: rawAnswer } = req.body || {};
    const question = typeof questionId === "string" ? questionById.get(questionId) : undefined;
    if (!question) return res.status(400).json({ error: "Pertanyaannya nggak dikenal." });

    const { answer, error } = validateAnswer(question, rawAnswer);
    if (error) return res.status(400).json({ error });

    await appendAnswer(question, answer);
    res.status(201).json({ ok: true });
  } catch (error) {
    next(error);
  }
});

api.use((req, res) => res.status(404).json({ error: "Tidak ditemukan." }));

app.use("/api", api);

/* ------------------------------------------------------------------ */
/* File website                                                        */
/* ------------------------------------------------------------------ */

// Hanya file di daftar ini yang boleh dibuka sebelum login. Pendekatannya
// "tolak kecuali terdaftar", jadi path aneh seperti /assets/%70hotos/... atau
// /assets/fonts/../photos/... otomatis ditolak.
const OPEN_BEFORE_LOGIN = /^\/(?:|index\.html|style\.css|script\.js|favicon\.ico|assets\/fonts\/[\w-]+\.woff2|assets\/decorations\/[\w-]+\.svg)$/;

app.use((req, res, next) => {
  if (OPEN_BEFORE_LOGIN.test(req.path) || req.session.authenticated === true) return next();
  res.status(404).type("text/plain").send("Tidak ditemukan.");
});

app.use(
  express.static(PUBLIC_DIR, {
    dotfiles: "deny",
    index: "index.html",
    setHeaders(res, filePath) {
      const isFont = filePath.endsWith(".woff2");
      res.setHeader("Cache-Control", isFont ? "public, max-age=2592000, immutable" : "private, no-cache");
    },
  })
);

app.use((req, res) => res.status(404).type("text/plain").send("Tidak ditemukan."));

// Detail error hanya masuk ke log server, tidak pernah ke pengunjung.
app.use((error, req, res, next) => {
  if (res.headersSent) return next(error);
  const status = error.status || error.statusCode || 500;
  if (status >= 500) console.error("[Server error]", error);
  const message = status === 413 ? "Datanya kebesaran, dek." : status < 500 ? "Permintaannya nggak valid." : GENERIC_ERROR_MESSAGE;
  if (req.path.startsWith("/api")) return res.status(status).json({ error: message });
  res.status(status).type("text/plain").send(message);
});

app.listen(PORT, () => {
  console.log(`\n  24 Chapters of You sudah berjalan di http://localhost:${PORT}\n`);
});
