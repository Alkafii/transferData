# 24 Chapters of You: A Birthday Story for Cerinova

Website ulang tahun interaktif untuk Cerinova Hazanah, dari Muhammad Ghossan Alkafi.

## Cara menjalankan

Butuh [Node.js](https://nodejs.org) versi 18 atau lebih baru. Buka terminal di folder ini, lalu:

```bash
npm install
npm start
```

Buka **http://localhost:3000**. Untuk menghentikan server, tekan `Ctrl + C`.

**Mencoba di HP:** sambungkan HP dan laptop ke WiFi yang sama, lalu buka `http://IP-LAPTOP:3000` di HP.

### Sebelum website dikirim ke Cerin

1. Kosongkan `data/answers.txt` dari jawaban percobaanmu.
2. Kalau sempat mencoba di HP Cerin, gunakan mode incognito. Browser mengingat jawaban dan progres, sehingga pertanyaan yang sudah dijawab tidak akan ditanyakan lagi di browser yang sama.

## Struktur project

| File | Fungsi |
| --- | --- |
| `public/config.js` | **Semua konten:** foto, pertanyaan, pesan, surat, durasi, musik |
| `public/index.html` | Kerangka halaman dan teks halaman login |
| `public/style.css` | Warna, font, layout, animasi |
| `public/script.js` | Mesin slideshow, pertanyaan, musik |
| `server.js` | Login, keamanan, penyimpanan jawaban |
| `scripts/set-login.js` | Alat untuk mengganti username dan password |
| `.env` | Username, hash password, dan rahasia sesi. **Jangan dibagikan** |
| `data/answers.txt` | Jawaban Cerin |

Hampir semua perubahan cukup dilakukan di `public/config.js`.

## 1. Mengubah username dan password

```bash
npm run set-login
```

Isi username dan password baru, lalu jalankan ulang server. Password disimpan sebagai hash bcrypt di `.env`, bukan sebagai teks biasa. Teks keterangan di halaman login ada di `public/index.html`.

## 2. Mengganti foto

Simpan foto ke `public/assets/photos/` dengan nama `photo1.jpg`, `photo2.jpg`, dan seterusnya. Foto yang belum ada otomatis digantikan placeholder bertuliskan nama file yang dibutuhkan, jadi kamu bisa melihat foto mana yang kurang.

- **Foto iPhone:** format `.heic` tidak tampil di semua browser. Ubah dulu ke `.jpg`.
- **Ukuran:** sisi terpanjang sekitar 1600 piksel sudah cukup, agar cepat dibuka lewat data seluler.
- **Slide 2 dan 4:** masing-masing memakai satu foto, diatur lewat `image` pada slide `portrait` dan `story`.
- **Caption dan tanggal:** diubah di daftar `memories`. Isian `date` boleh dikosongkan.

## 3. Menambahkan foto baru

Simpan fotonya, lalu tambahkan satu baris di `memories` pada `public/config.js`:

```js
{ image: "assets/photos/photo7.jpg", caption: "Caption fotonya.", date: "1 Januari 2026" },
```

Urutan di daftar adalah urutan tampilnya. Slide *Photo Memories* memakai semua foto di daftar, sedangkan slide polaroid memakai beberapa foto pertama sesuai isian `count` (3 sampai 5). Kalau wajah terpotong pada polaroid, tambahkan `position: "center top"` pada item fotonya.

## 4. Mengganti background music

Timpa `public/assets/music/background-music.mp3` dengan lagumu, memakai nama file yang sama. File bawaan hanyalah musik pengganti sementara. Volume diatur lewat `music.volume` di `config.js`.

Musik baru mulai saat Cerin mengetuk amplop, karena browser melarang musik berputar sebelum ada interaksi.

## 5. Mengubah pertanyaan

Semua pertanyaan ada di daftar `questions` pada `config.js`:

```js
{
  id: "favorite_ramen",
  type: "text",                   // text, textarea, date, atau radio
  look: "ramen",                  // calendar, note, ramen, ticket, planner, oneword, film
  title: "Apa nama ramen favorit kita?",
  placeholder: "Nama ramennya...",
  response: "Nah, abis ini kita ke sana lagi ya 🍜",
},
```

- **Mengubah:** ganti teksnya. Pilihan jawaban ada di `options`, dan tiap pilihan boleh punya `response` sendiri.
- **Menambah:** tambahkan item di `questions` dengan `id` baru, lalu tambahkan baris ini di `slides` pada posisi yang kamu mau:
  ```js
  { type: "question", chapter: "Question Time", questionId: "id_baru" },
  ```
- **Menghapus:** hapus dari `questions` dan dari `slides`.

Setelah mengubah pertanyaan, **jalankan ulang server**, karena server memakai daftar yang sama untuk memeriksa jawaban.

## 6. Mengubah pesan di setiap slide

Cari slide-nya di daftar `slides` pada `config.js`, lalu ubah teksnya.

- **Surat cinta:** variabel `letter`, tepat di atas daftar `slides`. Baris kosong menjadi paragraf baru.
- **Durasi:** `duration` dalam milidetik (`10000` berarti 10 detik). Beberapa slide memakai `itemDuration`, `paragraphDuration`, `pageDuration`, atau `photoDuration`.
- **Menghapus atau memindahkan slide:** hapus atau pindahkan satu blok `{ ... }`. Penomoran chapter menyesuaikan otomatis.

Beberapa isi ditulis sebagai contoh dan sebaiknya kamu sesuaikan dengan cerita kalian: surat, `Our Little Story`, akrostik nama, voucher, dan amplop *Open When*. Isi voucher adalah janji sungguhan, jadi pastikan kamu sanggup menepatinya. Kalau judul voucher diubah, samakan juga dengan `options` pada pertanyaan `voucher_claim`.

## 7. Membaca jawaban Cerin

Buka `data/answers.txt` dengan editor teks apa pun. Setiap jawaban langsung ditambahkan ke file itu beserta waktunya. Jawaban lama tidak pernah ditimpa, jadi kalau Cerin menjawab ulang, kedua jawaban tetap ada. Voucher yang diklaim juga tercatat di sini.

File ini berada di luar folder `public`, sehingga tidak bisa dibuka lewat browser.

Melihat jawaban baru secara langsung:

```bash
tail -f data/answers.txt
```

## 8. Mengunggah website secara aman

Kalau website dibuka dari internet, pastikan hal-hal berikut:

1. **Wajib HTTPS.** Set `NODE_ENV=production`. Pada mode ini cookie hanya dikirim lewat HTTPS, jadi login tidak akan berhasil lewat `http://`.
2. **Reverse proxy.** Set `TRUST_PROXY=1` kalau ada satu proxy di depan aplikasi. Hampir semua hosting dan Nginx/Caddy termasuk kategori ini.
3. **Penyimpanan permanen.** Jawaban disimpan sebagai file, jadi hosting harus mempertahankan file saat restart.
   - **Cocok:** VPS, atau layanan yang menyediakan persistent disk untuk folder `data/`.
   - **Tidak cocok:** Vercel, Netlify, dan hosting serverless sejenis.
   - **Berisiko:** paket hosting yang filesystem-nya terhapus setiap deploy atau restart. Jawaban Cerin bisa hilang.
4. **Sesi tersimpan di memori.** Kalau server restart, Cerin perlu login lagi. Jawabannya tetap aman.
5. **Jangan mengunggah rahasia.** `.env` dan `data/answers.txt` sudah masuk `.gitignore`. Kalau memakai GitHub, buat repository **private**, karena foto kalian ikut tersimpan di sana. Di hosting, isi nilai dari `.env` lewat menu environment variables.

Contoh konfigurasi Caddy di VPS, yang mengurus HTTPS secara otomatis:

```
hadiah-cerin.example.com {
    reverse_proxy localhost:3000
}
```

Gunakan juga pengelola proses seperti `pm2` agar server hidup lagi setelah VPS restart:

```bash
npm install -g pm2
NODE_ENV=production TRUST_PROXY=1 pm2 start server.js --name cerin
pm2 save
```

## Keamanan yang sudah diterapkan

- Password disimpan sebagai hash bcrypt di `.env` dan tidak pernah dikirim ke browser.
- Login memakai sesi di server, dengan cookie HttpOnly, SameSite, dan Secure saat production.
- Login dibatasi 10 percobaan gagal per 15 menit, dan semua permintaan yang mengubah data memakai token CSRF.
- Sebelum login, hanya halaman login, CSS, script, dan font yang bisa dibuka. Foto, musik, dan `config.js` tertutup.
- Jawaban diperiksa di server: pertanyaan harus dikenal, tipe dan panjang harus sesuai, pilihan harus ada di daftar.
- Security headers memakai Helmet, ukuran request dibatasi 10 KB, dan detail error hanya masuk ke log server.

## Lisensi font

Playfair Display, Cormorant Garamond, dan Poppins memakai SIL Open Font License dan disimpan di `public/assets/fonts/`, jadi website tidak bergantung pada layanan font luar.
