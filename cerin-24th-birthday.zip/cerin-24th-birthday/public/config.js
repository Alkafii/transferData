/*
 * config.js: SEMUA KONTEN WEBSITE ADA DI SINI
 *
 * Kamu bisa mengubah foto, caption, pertanyaan, pesan, surat, durasi, dan musik
 * tanpa menyentuh kode lain. Aturan penulisan:
 *   - Teks ditulis di dalam tanda kutip "...".
 *   - Setiap item dipisahkan koma.
 *   - Durasi ditulis dalam milidetik: 1000 = 1 detik.
 *
 * Setelah mengubah PERTANYAAN, restart server (Ctrl+C lalu npm start).
 * Perubahan lain cukup dengan me-refresh browser.
 */

/* ===================== 1. MUSIK ===================== */

const music = {
  file: "assets/music/background-music.mp3",
  volume: 0.55, // 0 sampai 1
};

/* ===================== 2. FOTO KENANGAN =====================
 * Urutan di sini adalah urutan tampilnya foto.
 * date boleh dikosongkan: "".
 * position mengatur bagian foto yang diutamakan pada polaroid, misalnya
 * "center top" kalau wajah ada di bagian atas foto (boleh tidak ditulis).
 */

const memories = [
  { image: "assets/photos/photo1.jpg", caption: "One of my favorite memories with you.", date: "15 September 2023" },
  { image: "assets/photos/photo2.jpg", caption: "Another beautiful day together.", date: "" },
  { image: "assets/photos/photo3.jpg", caption: "Kamu lagi ketawa, aku lagi jatuh cinta lagi.", date: "" },
  { image: "assets/photos/photo4.jpg", caption: "Hari biasa yang jadi nggak biasa.", date: "" },
  { image: "assets/photos/photo5.jpg", caption: "Kalau bisa, aku mau balik ke sini.", date: "" },
  { image: "assets/photos/photo6.jpg", caption: "Masih banyak foto yang belum kita ambil.", date: "" },
];

/* ===================== 3. PERTANYAAN =====================
 * id          nama unik, muncul di answers.txt (huruf, angka, garis bawah)
 * type        "text" | "textarea" | "date" | "radio"
 * look        tampilan: "calendar" | "note" | "ramen" | "ticket" | "planner" | "oneword" | "film"
 * title       teks pertanyaan
 * placeholder teks samar di dalam kotak isian
 * response    balasan setelah menjawab
 * options     khusus radio. Boleh teks biasa, atau { label, response } kalau
 *             tiap pilihan punya balasan berbeda
 * maxLength   batas jumlah karakter (boleh tidak ditulis)
 *
 * Menambah pertanyaan: tambahkan satu item di sini, lalu tambahkan
 *   { type: "question", questionId: "id_baru", chapter: "Question Time" }
 * di daftar slides di bawah. Menghapus: hapus dari kedua tempat.
 */

const questions = [
  {
    id: "first_meeting",
    type: "date",
    look: "calendar",
    title: "Kamu masih ingat nggak, kapan pertama kali kita ketemu?",
    placeholder: "Tulis sendiri, misalnya: awal September 2023",
    response: "Hehehe, ternyata kamu masih ingat ❤️",
  },
  {
    id: "favorite_thing",
    type: "textarea",
    look: "note",
    title: "Kamu paling seneng kalau Ghossan ngapain?",
    placeholder: "Ceritain dong dek...",
    response: "Oke, dicatat. Mas bakal lebih sering ngelakuin itu ❤️",
  },
  {
    id: "favorite_ramen",
    type: "text",
    look: "ramen",
    title: "Apa nama ramen favorit kita?",
    placeholder: "Nama ramennya...",
    response: "Nah, abis ini kita ke sana lagi ya 🍜",
  },
  {
    id: "jogja_trip",
    type: "radio",
    look: "ticket",
    title: "Kapan-kapan ke Jogja lagi naik Sugeng Rahayu yuk, dek? 🥺",
    options: [
      { label: "Yesss, let's go!", response: "Deal! Kursinya sebelahan, kamu yang dekat jendela ❤️" },
      { label: "Nanti dulu ya, Mas.", response: "Oke, Mas tunggu. Tiketnya Mas simpan dulu ya 🥺" },
      { label: "Tentu sajaaa!", response: "Nah gitu dong! Siapin camilannya dari sekarang 🚌" },
    ],
  },
  {
    id: "full_day",
    type: "textarea",
    look: "planner",
    title: "Kalau kita punya satu hari full buat quality time, kamu mau ngapain sama Mas?",
    placeholder: "Dari pagi sampai malam, terserah kamu...",
    response: "Kedengarannya sempurna. Tinggal pilih tanggalnya ❤️",
  },
  {
    id: "one_word",
    type: "text",
    look: "oneword",
    title: "Satu kata yang paling menggambarkan hubungan kita menurut kamu apa?",
    placeholder: "Satu kata...",
    maxLength: 60,
    maxWords: 1, // hapus baris ini kalau boleh lebih dari satu kata
    response: "Satu kata itu bakal Mas ingat terus ❤️",
  },
  {
    id: "repeat_moment",
    type: "textarea",
    look: "film",
    title: "Kalau boleh mengulang satu momen bersama Mas, kamu mau mengulang momen yang mana?",
    placeholder: "Putar ulang momennya di sini...",
    response: "Yang itu ya... Mas juga mau ngulang. Yuk, kita bikin yang baru juga ❤️",
  },
  {
    // Bukan pertanyaan yang ditampilkan: dipakai slide voucher untuk mencatat
    // voucher yang diklaim. Isi options harus sama dengan judul di slide voucher.
    id: "voucher_claim",
    type: "radio",
    title: "Voucher yang diklaim Cerin",
    options: [
      "Satu mangkuk ramen",
      "Menang debat sekali",
      "Pijat pundak 15 menit",
      "Bebas bilang \"terserah\"",
    ],
  },
];

/* ===================== 4. SURAT CINTA =====================
 * Ganti sesukamu. Baris kosong membuat paragraf baru.
 */

const letter = `Dek,

Aku sebenernya nggak jago nulis yang manis-manis, makanya aku bikinin ini aja. Sedikit kode, banyak mikirin kamu.

Umur kamu sekarang 24. Aku nggak tahu kamu ngerasa udah sampai mana, tapi dari sini aku lihat kamu udah jauh banget. Kamu sering nggak sadar seberapa keren kamu ngadepin semuanya, jadi hari ini biar aku yang bilang.

Makasih ya, udah sabar sama aku. Sama aku yang kadang telat ngerti, kadang kebanyakan diem, kadang salah ngomong. Makasih juga udah tetep milih buat ada.

Aku nggak bisa janji semua hari bakal gampang. Tapi aku bisa janji satu hal: di hari yang gampang maupun yang susah, kamu nggak bakal ngelewatinnya sendirian.

Selamat ulang tahun, Cerin. Selamat nambah satu chapter lagi. Semoga aku boleh ada di chapter-chapter berikutnya.

Yang sayang sama kamu,
Mas Ghossan`;

/* ===================== 5. URUTAN SLIDE =====================
 * Urutan di daftar ini adalah urutan tampilnya. Untuk menghapus slide,
 * hapus satu blok { ... }. Untuk memindahkan, pindahkan bloknya.
 * transition: "fade" | "zoom" | "blur" | "rise"
 */

const slides = [
  {
    type: "welcome",
    chapter: "Welcome",
    duration: 10000,
    transition: "fade",
    title: "Happy 24th Birthday, My Dearest Cerinova ❤️",
    subtitle: "Today is not just another day. Today is the day someone incredibly special came into this world.",
  },
  {
    type: "portrait",
    chapter: "A Special Person",
    duration: 8500,
    transition: "blur",
    image: "assets/photos/photo1.jpg",
    text: "To the girl who makes ordinary days feel extraordinary.",
  },
  {
    type: "acrostic",
    chapter: "Your Name",
    duration: 17000,
    transition: "rise",
    title: "Delapan huruf, dan semuanya kamu.",
    lines: [
      { letter: "C", text: "Cantik, bahkan waktu baru bangun." },
      { letter: "E", text: "Entah kenapa selalu bikin aku senyum." },
      { letter: "R", text: "Rumah, tempat aku mau pulang." },
      { letter: "I", text: "Istimewa, tanpa perlu usaha." },
      { letter: "N", text: "Nyaman, setiap kali bareng kamu." },
      { letter: "O", text: "Obat capek paling ampuh." },
      { letter: "V", text: "Versi terbaik dari hari-hariku." },
      { letter: "A", text: "Alasan aku semangat tiap pagi." },
    ],
  },
  {
    type: "story",
    chapter: "Our Little Story",
    duration: 14000,
    transition: "fade",
    image: "assets/photos/photo2.jpg",
    caption: "Awal dari semuanya.",
    title: "Our little story",
    text: "Semuanya mulai dari hal yang kelihatannya biasa aja. Satu pertemuan, beberapa obrolan, terus tiba-tiba aku sadar kalau hariku jadi lebih seru kalau ada kamu. Dari situ, pelan-pelan, ceritaku jadi cerita kita.",
  },
  { type: "question", chapter: "Question Time #1", questionId: "first_meeting", transition: "zoom" },
  {
    type: "loves",
    chapter: "Things I Love About You",
    transition: "blur",
    itemDuration: 4000,
    items: [
      { text: "Your smile.", note: "Yang bikin aku lupa tadi mau ngomong apa." },
      { text: "Your little habits.", note: "Yang kamu kira nggak aku perhatiin. Aku perhatiin." },
      { text: "The way you care.", note: "Diam-diam, tapi selalu kerasa." },
      { text: "Your laugh.", note: "Apalagi kalau ketawanya gara-gara aku." },
      { text: "Simply being you.", note: "Nggak perlu jadi siapa-siapa lagi." },
    ],
  },
  {
    type: "polaroids",
    chapter: "Our Favorite Memories",
    duration: 16000,
    transition: "rise",
    title: "Our favorite memories",
    count: 4, // jumlah foto yang ditampilkan (3 sampai 5), diambil dari awal daftar memories
  },
  { type: "question", chapter: "Question Time #2", questionId: "favorite_thing", transition: "fade" },
  { type: "question", chapter: "Our Favorite Food", questionId: "favorite_ramen", transition: "rise" },
  {
    type: "appreciation",
    chapter: "A Little Appreciation",
    transition: "blur",
    paragraphDuration: 7500,
    title: "A little appreciation",
    paragraphs: [
      "Makasih ya, udah jadi bagian dari perjalanan hidupku. Banyak hal jadi lebih ringan sejak ada kamu.",
      "Makasih buat sabarnya, buat waktunya, dan buat semua hal kecil yang mungkin kamu kira nggak aku sadari.",
      "Semoga kamu selalu sehat dan bahagia, dan semoga yang kamu perjuangkan pelan-pelan sampai ke kamu.",
      "Semoga kita juga terus tumbuh, sama-sama, dan makin ngerti satu sama lain dari hari ke hari.",
    ],
  },
  { type: "question", chapter: "Question Time #3", questionId: "jogja_trip", transition: "zoom" },
  {
    type: "bucket",
    chapter: "Our Bucket List",
    duration: 17000,
    transition: "fade",
    title: "Our bucket list",
    hint: "Centang yang paling kamu mau duluan.",
    items: [
      "Traveling together.",
      "Trying new restaurants.",
      "Watching sunsets.",
      "More spontaneous adventures.",
      "Building our future together.",
    ],
  },
  { type: "question", chapter: "Question Time #4", questionId: "full_day", transition: "rise" },
  {
    type: "vouchers",
    chapter: "Birthday Vouchers",
    duration: 18000,
    transition: "zoom",
    title: "Hadiah kecil, berlaku seumur hidup.",
    hint: "Klaim yang kamu mau. Mas nggak bisa nolak, ini udah tercatat.",
    questionId: "voucher_claim",
    items: [
      { title: "Satu mangkuk ramen", note: "Mas yang bayar. Boleh tambah topping." },
      { title: "Menang debat sekali", note: "Tanpa banding. Mas langsung bilang kamu benar." },
      { title: "Pijat pundak 15 menit", note: "Tanpa \"nanti ya\"." },
      { title: "Bebas bilang \"terserah\"", note: "Mas yang mikirin mau makan apa." },
    ],
  },
  {
    type: "numbers",
    chapter: "24, in Numbers",
    duration: 14000,
    transition: "blur",
    title: "24 tahun itu kira-kira...",
    items: [
      { value: 8766, label: "hari" },
      { value: 210384, label: "jam" },
      { value: 946, label: "juta detak jantung" },
    ],
    closing: "Dan aku bersyukur banget bisa ada di sebagian kecilnya.",
  },
  {
    type: "wishes",
    chapter: "24 Things I Wish For You",
    transition: "fade",
    pageDuration: 5500,
    title: "24 things I wish for you",
    items: [
      "More happiness.", "Better health.", "Endless blessings.", "Career success.", "More beautiful memories.", "More reasons to smile.",
      "Calmer mornings.", "Deeper sleep.", "Braver decisions.", "Kinder days.", "Good news, often.", "Friends who stay.",
      "A heart at peace.", "Fewer worries.", "More adventures.", "Bigger dreams.", "Doors that open.", "Patience for hard days.",
      "Strength when you need it.", "Time for yourself.", "Ramen that never disappoints.", "Laughing until it hurts.", "Prayers answered, one by one.", "And me, right beside you.",
    ],
  },
  { type: "question", chapter: "Question Time #5", questionId: "one_word", transition: "blur" },
  {
    type: "reel",
    chapter: "Photo Memories",
    transition: "fade",
    photoDuration: 6000, // lama tiap foto. Fotonya otomatis dari daftar memories.
  },
  {
    type: "letter",
    chapter: "A Letter For You",
    transition: "rise",
    title: "A letter for you",
    typingSpeed: 32, // milidetik per huruf, makin kecil makin cepat
    holdAfterTyping: 12000,
  },
  { type: "question", chapter: "Question Time #6", questionId: "repeat_moment", transition: "fade" },
  {
    type: "openwhen",
    chapter: "Open When",
    duration: 18000,
    transition: "rise",
    title: "Buat disimpan, kalau suatu hari butuh.",
    hint: "Ketuk salah satu amplop.",
    items: [
      { label: "Buka kalau lagi capek", note: "Udahan dulu kerjanya. Kabarin Mas, nanti kita cari makan. Nggak usah mikir apa-apa." },
      { label: "Buka kalau lagi kangen", note: "Mas juga. Nggak usah gengsi, telepon aja sekarang." },
      { label: "Buka kalau lagi sedih", note: "Kamu nggak harus kuat terus. Telepon Mas. Nggak usah ngomong apa-apa juga boleh." },
      { label: "Buka kalau lagi ragu sama diri sendiri", note: "Coba lihat lagi semua yang udah kamu lewatin. Kamu lebih hebat dari yang kamu kira, dek." },
    ],
  },
  {
    type: "future",
    chapter: "The Future",
    duration: 12000,
    transition: "blur",
    text: "We still have so many stories to write, places to visit, and memories to create.",
  },
  {
    type: "cake",
    chapter: "Birthday Cake",
    transition: "fade",
    title: "Make a wish, my love.",
    button: "Tiup lilinnya",
    afterTitle: "Semoga semuanya terkabul, ya.",
    holdAfterBlow: 9000,
  },
  {
    type: "final",
    chapter: "With Love",
    transition: "blur",
    title: "Happy 24th Birthday, Cerinova Hazanah.",
    text: "Thank you for being you. Thank you for being part of my life.",
    signoff: "With love,",
    signature: "Ghossan ❤️",
    nextChapter: "Chapter 25 dimulai hari ini. Aku ikut, ya?",
    replay: "Baca lagi dari awal",
    logout: "Keluar",
  },
];

/* ===== Jangan ubah bagian di bawah ini ===== */
const STORY_CONFIG = { music, memories, questions, letter, slides };
if (typeof module !== "undefined") module.exports = STORY_CONFIG;
else window.STORY_CONFIG = STORY_CONFIG;
