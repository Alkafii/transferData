/*
 * script.js: mesin website "24 Chapters of You"
 *
 * Isi file ini berurutan:
 *   1. Alat bantu kecil         5. Login dan amplop
 *   2. Komunikasi dengan server 6. Mesin slideshow
 *   3. Notifikasi dan partikel  7. Tampilan setiap jenis slide
 *   4. Musik                    8. Pertanyaan
 *
 * Isi cerita TIDAK ada di sini, melainkan di config.js yang baru dimuat
 * setelah login berhasil. Untuk mengubah teks, foto, atau pertanyaan,
 * cukup ubah config.js.
 */
(() => {
  "use strict";

  /* ================================================================== */
  /* 1. ALAT BANTU                                                       */
  /* ================================================================== */

  const $ = (selector) => document.querySelector(selector);
  const REDUCED_MOTION = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const clamp = (value, min, max) => Math.min(max, Math.max(min, value));
  const random = (min, max) => min + Math.random() * (max - min);

  /** Membuat elemen. Teks selalu lewat textContent, sehingga aman dari HTML injection. */
  function h(tag, props = {}, ...children) {
    const element = document.createElement(tag);
    for (const [key, value] of Object.entries(props)) {
      if (value === undefined || value === null || value === false) continue;
      if (key === "class") element.className = value;
      else if (key === "text") element.textContent = value;
      else if (key === "svg") element.innerHTML = value; // hanya untuk SVG buatan file ini
      else if (key === "delay") element.style.setProperty("--d", `${value}ms`);
      else if (key.startsWith("on")) element.addEventListener(key.slice(2), value);
      else element.setAttribute(key, value === true ? "" : value);
    }
    for (const child of children.flat()) {
      if (child !== null && child !== undefined && child !== false) element.append(child);
    }
    return element;
  }

  /** Penyimpanan kecil di browser: progres, draf, dan jawaban yang sudah terkirim. */
  const memory = {
    get(key, fallback) {
      try {
        const raw = localStorage.getItem(`cerin.${key}`);
        return raw === null ? fallback : JSON.parse(raw);
      } catch {
        return fallback;
      }
    },
    set(key, value) {
      try {
        localStorage.setItem(`cerin.${key}`, JSON.stringify(value));
      } catch {
        /* mode privat: website tetap berjalan tanpa penyimpanan */
      }
    },
    patch(key, field, value) {
      const current = memory.get(key, {});
      if (value === undefined) delete current[field];
      else current[field] = value;
      memory.set(key, current);
    },
  };

  const ICONS = {
    play: '<svg viewBox="0 0 24 24"><path d="M8 5.5v13l10.5-6.5z"/></svg>',
    pause: '<svg viewBox="0 0 24 24"><rect x="7" y="5.5" width="3.6" height="13" rx="1"/><rect x="13.4" y="5.5" width="3.6" height="13" rx="1"/></svg>',
    back: '<svg viewBox="0 0 24 24"><path class="stroke" d="M14.5 5.5 8 12l6.5 6.5"/></svg>',
    next: '<svg viewBox="0 0 24 24"><path class="stroke" d="M9.5 5.5 16 12l-6.5 6.5"/></svg>',
    note: '<svg viewBox="0 0 24 24"><path d="M9 17.5V6.2l10-2v11.3" class="stroke"/><ellipse cx="6.6" cy="17.6" rx="2.6" ry="2.1"/><ellipse cx="16.6" cy="15.6" rx="2.6" ry="2.1"/></svg>',
    soundOn: '<svg viewBox="0 0 24 24"><path d="M4 9.5v5h3.5L12 18.5v-13L7.5 9.5z"/><path class="stroke" d="M15.5 9a4.2 4.2 0 0 1 0 6M18 6.5a7.8 7.8 0 0 1 0 11"/></svg>',
    soundOff: '<svg viewBox="0 0 24 24"><path d="M4 9.5v5h3.5L12 18.5v-13L7.5 9.5z"/><path class="stroke" d="m15.5 9.5 5 5m0-5-5 5"/></svg>',
    equalizer: '<span class="eq" aria-hidden="true"><i></i><i></i><i></i></span>',
    heart: '<svg viewBox="0 0 24 24"><path d="M12 20.5C5.6 16.3 3 12.8 3 9.3 3 6.4 5.2 4.3 7.9 4.3c1.7 0 3.2.9 4.1 2.4.9-1.5 2.4-2.4 4.1-2.4C18.8 4.3 21 6.4 21 9.3c0 3.5-2.6 7-9 11.2Z"/></svg>',
    check: '<svg viewBox="0 0 28 28"><rect class="box" x="3" y="3" width="22" height="22" rx="6"/><path class="tick" d="m8 14.5 4.2 4.2L20.2 10"/></svg>',
  };

  /* ================================================================== */
  /* 2. KOMUNIKASI DENGAN SERVER                                         */
  /* ================================================================== */

  let csrfToken = "";

  async function refreshSession() {
    const response = await fetch("/api/session", { credentials: "same-origin" });
    if (!response.ok) throw new Error("session");
    const data = await response.json();
    csrfToken = data.csrfToken;
    return data;
  }

  /** Mengirim POST ke API. Kalau token CSRF kedaluwarsa, diperbarui dan dicoba sekali lagi. */
  async function post(url, body, canRetry = true) {
    const response = await fetch(url, {
      method: "POST",
      credentials: "same-origin",
      headers: { "Content-Type": "application/json", "X-CSRF-Token": csrfToken },
      body: JSON.stringify(body),
    });
    if (response.status === 403 && canRetry) {
      await refreshSession();
      return post(url, body, false);
    }
    let data = {};
    try {
      data = await response.json();
    } catch {
      /* respons bukan JSON */
    }
    return { ok: response.ok, status: response.status, data };
  }

  /* ================================================================== */
  /* 3. NOTIFIKASI DAN PARTIKEL                                          */
  /* ================================================================== */

  function toast(message, kind = "info") {
    const element = h("div", { class: `toast toast--${kind}`, text: message });
    $("#toasts").append(element);
    setTimeout(() => {
      element.classList.add("toast--out");
      setTimeout(() => element.remove(), 400);
    }, 3800);
  }

  function heartPath(ctx, size) {
    const s = size / 2;
    ctx.beginPath();
    ctx.moveTo(0, s * 0.9);
    ctx.bezierCurveTo(-s * 1.3, 0, -s, -s, -s * 0.45, -s * 0.85);
    ctx.bezierCurveTo(-s * 0.15, -s * 0.85, 0, -s * 0.6, 0, -s * 0.4);
    ctx.bezierCurveTo(0, -s * 0.6, s * 0.15, -s * 0.85, s * 0.45, -s * 0.85);
    ctx.bezierCurveTo(s, -s, s * 1.3, 0, 0, s * 0.9);
    ctx.closePath();
  }

  /* Cara menggambar dan menggerakkan tiap jenis partikel latar. */
  const PARTICLE_KINDS = {
    hearts: {
      count: 12,
      make(w, h2, anywhere) {
        return { x: random(0, w), y: anywhere ? random(0, h2) : h2 + 30, size: random(9, 22), speed: random(10, 24), sway: random(0, 6), alpha: random(0.18, 0.5), color: Math.random() > 0.5 ? "#D8A7A7" : "#763D4B" };
      },
      step(p, dt, t) {
        p.y -= p.speed * dt;
        p.dx = Math.sin(t * 0.6 + p.sway) * 14;
        return p.y > -30;
      },
      draw(c, p) {
        c.translate(p.x + p.dx, p.y);
        c.globalAlpha = p.color === "#763D4B" ? p.alpha * 0.45 : p.alpha;
        c.fillStyle = p.color;
        heartPath(c, p.size);
        c.fill();
      },
    },
    petals: {
      count: 12,
      make(w, h2, anywhere) {
        return { x: random(0, w), y: anywhere ? random(0, h2) : -20, size: random(8, 15), speed: random(16, 32), sway: random(0, 6), spin: random(-1, 1), angle: random(0, 6), alpha: random(0.35, 0.7), color: Math.random() > 0.4 ? "#D8A7A7" : "#F4DDE1" };
      },
      step(p, dt, t, w, h2) {
        p.y += p.speed * dt;
        p.dx = Math.sin(t * 0.8 + p.sway) * 22;
        p.angle += p.spin * dt;
        return p.y < h2 + 24;
      },
      draw(c, p, t) {
        c.translate(p.x + p.dx, p.y);
        c.rotate(p.angle);
        c.scale(1, 0.55 + Math.abs(Math.sin(t + p.sway)) * 0.45);
        c.globalAlpha = p.alpha;
        c.fillStyle = p.color;
        c.beginPath();
        c.moveTo(0, -p.size);
        c.bezierCurveTo(p.size, -p.size * 0.5, p.size * 0.8, p.size * 0.6, 0, p.size);
        c.bezierCurveTo(-p.size * 0.8, p.size * 0.6, -p.size, -p.size * 0.5, 0, -p.size);
        c.fill();
      },
    },
    balloons: {
      count: 7,
      make(w, h2, anywhere) {
        const colors = ["#D8A7A7", "#763D4B", "#D6B77A", "#F4DDE1"];
        return { x: random(16, w - 16), y: anywhere ? random(h2 * 0.3, h2 * 1.3) : h2 + 90, size: random(17, 30), speed: random(20, 38), sway: random(0, 6), color: colors[Math.floor(random(0, colors.length))], alpha: random(0.75, 0.95) };
      },
      step(p, dt, t) {
        p.y -= p.speed * dt;
        p.dx = Math.sin(t * 0.5 + p.sway) * 16;
        return p.y > -110;
      },
      draw(c, p, t) {
        const s = p.size;
        c.translate(p.x + p.dx, p.y);
        c.globalAlpha = p.alpha;
        c.strokeStyle = "rgba(118,61,75,.35)";
        c.lineWidth = 1;
        c.beginPath();
        c.moveTo(0, s * 1.25);
        c.quadraticCurveTo(Math.sin(t + p.sway) * 9, s * 2, 0, s * 2.9);
        c.stroke();
        c.fillStyle = p.color;
        c.beginPath();
        c.ellipse(0, 0, s, s * 1.2, 0, 0, Math.PI * 2);
        c.fill();
        c.beginPath();
        c.moveTo(-s * 0.13, s * 1.17);
        c.lineTo(s * 0.13, s * 1.17);
        c.lineTo(0, s * 1.34);
        c.fill();
        c.globalAlpha = p.alpha * 0.35;
        c.fillStyle = "#FFFFFF";
        c.beginPath();
        c.ellipse(-s * 0.35, -s * 0.45, s * 0.2, s * 0.32, 0.5, 0, Math.PI * 2);
        c.fill();
      },
    },
    stars: {
      count: 110,
      make(w, h2) {
        return { x: random(0, w), y: Math.pow(Math.random(), 1.4) * h2, size: random(0.4, 1.8), phase: random(0, 6.3), rate: random(0.5, 1.8), gold: Math.random() > 0.8 };
      },
      step() {
        return true;
      },
      draw(c, p, t) {
        c.globalAlpha = 0.3 + 0.7 * Math.abs(Math.sin(t * p.rate + p.phase));
        c.fillStyle = p.gold ? "#D6B77A" : "#FFF8F0";
        c.beginPath();
        c.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        c.fill();
      },
    },
  };

  /** Satu kanvas partikel latar. Kanvas tidak menghalangi sentuhan. */
  class Ambient {
    constructor(canvas, kinds, density = 1) {
      this.canvas = canvas;
      this.ctx = canvas.getContext("2d");
      this.kinds = kinds;
      this.density = density;
      this.items = [];
      this.running = false;
      this.resize = this.resize.bind(this);
      this.frame = this.frame.bind(this);
    }
    resize() {
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      this.w = this.canvas.clientWidth;
      this.h = this.canvas.clientHeight;
      this.canvas.width = this.w * dpr;
      this.canvas.height = this.h * dpr;
      this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    }
    start() {
      this.resize();
      window.addEventListener("resize", this.resize);
      this.items = [];
      const sizeFactor = clamp(this.w / 700, 0.6, 1.4);
      for (const kind of this.kinds) {
        const def = PARTICLE_KINDS[kind];
        const count = Math.round(def.count * this.density * sizeFactor);
        for (let i = 0; i < count; i++) this.items.push({ kind, ...def.make(this.w, this.h, true) });
      }
      if (REDUCED_MOTION) {
        this.items = this.items.filter((p) => p.kind === "stars");
        this.paint(1);
        return;
      }
      this.running = true;
      this.last = performance.now();
      requestAnimationFrame(this.frame);
    }
    stop() {
      this.running = false;
      window.removeEventListener("resize", this.resize);
    }
    paint(t) {
      const c = this.ctx;
      c.clearRect(0, 0, this.w, this.h);
      for (const p of this.items) {
        c.save();
        PARTICLE_KINDS[p.kind].draw(c, p, t);
        c.restore();
      }
    }
    frame(now) {
      if (!this.running) return;
      const dt = Math.min((now - this.last) / 1000, 0.05);
      this.last = now;
      const t = now / 1000;
      this.items = this.items.map((p) => {
        const def = PARTICLE_KINDS[p.kind];
        return def.step(p, dt, t, this.w, this.h) ? p : { kind: p.kind, ...def.make(this.w, this.h, false) };
      });
      this.paint(t);
      requestAnimationFrame(this.frame);
    }
  }

  /** Confetti: satu ledakan dari atas layar, lalu kanvas berhenti sendiri. */
  const confetti = {
    canvas: null,
    pieces: [],
    running: false,
    burst(amount = 120) {
      if (REDUCED_MOTION) return;
      this.canvas = this.canvas || $("#confetti");
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      this.w = window.innerWidth;
      this.h = window.innerHeight;
      this.canvas.width = this.w * dpr;
      this.canvas.height = this.h * dpr;
      this.ctx = this.canvas.getContext("2d");
      this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      const colors = ["#D8A7A7", "#763D4B", "#D6B77A", "#F4DDE1", "#FFFFFF"];
      for (let i = 0; i < amount; i++) {
        this.pieces.push({
          x: random(0, this.w),
          y: random(-this.h * 0.5, -10),
          vx: random(-40, 40),
          vy: random(170, 300),
          w: random(5, 10),
          h: random(8, 15),
          angle: random(0, 6),
          spin: random(-5, 5),
          color: colors[i % colors.length],
          heart: i % 9 === 0,
        });
      }
      if (!this.running) {
        this.running = true;
        this.last = performance.now();
        requestAnimationFrame((now) => this.frame(now));
      }
    },
    frame(now) {
      const dt = Math.min((now - this.last) / 1000, 0.05);
      this.last = now;
      const c = this.ctx;
      c.clearRect(0, 0, this.w, this.h);
      this.pieces = this.pieces.filter((p) => p.y < this.h + 30);
      for (const p of this.pieces) {
        p.x += (p.vx + Math.sin(now / 400 + p.w) * 30) * dt;
        p.y += p.vy * dt;
        p.angle += p.spin * dt;
        c.save();
        c.translate(p.x, p.y);
        c.rotate(p.angle);
        c.fillStyle = p.color;
        if (p.heart) {
          heartPath(c, p.h * 1.2);
          c.fill();
        } else {
          c.scale(1, Math.abs(Math.cos(p.angle * 1.5)) * 0.8 + 0.2);
          c.fillRect(-p.w / 2, -p.h / 2, p.w, p.h);
        }
        c.restore();
      }
      if (this.pieces.length) requestAnimationFrame((next) => this.frame(next));
      else {
        this.running = false;
        c.clearRect(0, 0, this.w, this.h);
      }
    },
  };

  /* ================================================================== */
  /* 4. MUSIK                                                            */
  /* ================================================================== */

  const player = {
    audio: null,
    available: true,
    wantsMusic: memory.get("wantsMusic", true),
    muted: memory.get("muted", false),

    setup(config) {
      if (this.audio) return;
      this.audio = new Audio(config.file);
      this.audio.loop = true;
      this.audio.preload = "auto";
      this.audio.volume = clamp(config.volume ?? 0.55, 0, 1);
      this.audio.muted = this.muted;
      this.audio.addEventListener("error", () => {
        this.available = false;
        this.render();
      });
      this.audio.addEventListener("play", () => this.render());
      this.audio.addEventListener("pause", () => this.render());
      this.render();
    },
    /* Dipanggil dari ketukan pengguna, karena browser melarang autoplay sebelum ada interaksi. */
    start() {
      if (!this.audio || !this.wantsMusic || !this.available) return;
      const attempt = this.audio.play();
      if (attempt) attempt.catch(() => this.render());
    },
    toggle() {
      if (!this.available) {
        toast("File musiknya belum ada di server.");
        return;
      }
      this.wantsMusic = this.audio.paused;
      memory.set("wantsMusic", this.wantsMusic);
      if (this.wantsMusic) this.start();
      else this.audio.pause();
    },
    toggleMute() {
      this.muted = !this.muted;
      memory.set("muted", this.muted);
      if (this.audio) this.audio.muted = this.muted;
      this.render();
    },
    render() {
      const musicButton = $("#btn-music");
      const muteButton = $("#btn-mute");
      const isPlaying = Boolean(this.audio && !this.audio.paused);
      musicButton.innerHTML = isPlaying && !this.muted ? ICONS.equalizer : ICONS.note;
      musicButton.classList.toggle("is-off", !this.available || !isPlaying);
      musicButton.setAttribute("aria-label", isPlaying ? "Hentikan musik (sedang diputar)" : "Putar musik");
      muteButton.innerHTML = this.muted ? ICONS.soundOff : ICONS.soundOn;
      muteButton.setAttribute("aria-label", this.muted ? "Nyalakan suara musik" : "Bisukan musik");
      muteButton.setAttribute("aria-pressed", String(this.muted));
    },
  };

  /* Musik ikut berhenti saat tab disembunyikan, lalu lanjut saat kembali. */
  document.addEventListener("visibilitychange", () => {
    if (!player.audio) return;
    if (document.hidden) player.audio.pause();
    else if (story.started) player.start();
  });

  /* ================================================================== */
  /* 5. LOGIN DAN AMPLOP                                                 */
  /* ================================================================== */

  const screens = {
    show(id) {
      for (const screenId of ["login", "envelope-screen", "stage"]) {
        $(`#${screenId}`).hidden = screenId !== id;
      }
    },
  };

  let loginAmbient = null;
  let envelopeAmbient = null;

  function showLogin() {
    screens.show("login");
    document.body.dataset.tone = "light";
    if (!loginAmbient) loginAmbient = new Ambient($("#login-fx"), ["hearts"]);
    loginAmbient.start();
  }

  function setupLoginForm() {
    const form = $("#login-form");
    const errorText = $("#login-error");
    const submit = $("#login-submit");
    const password = $("#password");
    const toggle = $("#toggle-password");

    toggle.addEventListener("click", () => {
      const reveal = password.type === "password";
      password.type = reveal ? "text" : "password";
      toggle.textContent = reveal ? "Tutup" : "Lihat";
      toggle.setAttribute("aria-pressed", String(reveal));
    });

    const fail = (message) => {
      errorText.textContent = message;
      const card = $(".login-card");
      card.classList.remove("shake");
      void card.offsetWidth; // memulai ulang animasi
      card.classList.add("shake");
    };

    form.addEventListener("submit", async (event) => {
      event.preventDefault();
      errorText.textContent = "";
      const username = $("#username").value.trim();
      if (!username || !password.value) {
        fail("Isi dulu username dan password-nya, dek.");
        return;
      }
      submit.disabled = true;
      submit.textContent = "Sebentar...";
      try {
        if (!csrfToken) await refreshSession();
        const { ok, data } = await post("/api/login", { username, password: password.value });
        if (!ok) {
          fail(data.error || "username atau password salah dek");
          return;
        }
        csrfToken = data.csrfToken;
        password.value = "";
        await enterEnvelope();
      } catch {
        fail("Koneksinya lagi putus, dek. Coba lagi ya.");
      } finally {
        submit.disabled = false;
        submit.textContent = "Buka kejutannya";
      }
    });
  }

  /** config.js hanya bisa dimuat setelah login, jadi isi cerita tidak terbaca dari luar. */
  function loadConfig() {
    if (window.STORY_CONFIG) return Promise.resolve();
    return new Promise((resolve, reject) => {
      const script = document.createElement("script");
      script.src = "config.js";
      script.onload = () => (window.STORY_CONFIG ? resolve() : reject(new Error("config")));
      script.onerror = () => reject(new Error("config"));
      document.head.append(script);
    });
  }

  async function enterEnvelope() {
    await loadConfig();
    player.setup(window.STORY_CONFIG.music);
    if (loginAmbient) loginAmbient.stop();
    screens.show("envelope-screen");
    if (!envelopeAmbient) envelopeAmbient = new Ambient($("#envelope-fx"), ["petals"], 0.8);
    envelopeAmbient.start();

    const envelope = $("#envelope");
    envelope.classList.remove("is-open");
    $("#envelope-screen").classList.remove("is-leaving");
    const resumeAt = memory.get("progress", 0);
    const lastIndex = window.STORY_CONFIG.slides.length - 1;
    const resuming = resumeAt > 0 && resumeAt < lastIndex;
    $("#envelope-hint").textContent = resuming
      ? `Ketuk amplopnya untuk lanjut dari chapter ${resumeAt + 1}.`
      : "Ketuk amplopnya, dan nyalakan suaranya ya.";

    envelope.onclick = () => {
      envelope.onclick = null;
      player.start(); // ketukan ini adalah interaksi pertama, jadi musik boleh mulai
      envelope.classList.add("is-open");
      const wait = REDUCED_MOTION ? 300 : 2300;
      setTimeout(() => $("#envelope-screen").classList.add("is-leaving"), wait);
      setTimeout(() => {
        envelopeAmbient.stop();
        story.begin(resuming ? resumeAt : 0);
      }, wait + (REDUCED_MOTION ? 100 : 700));
    };
  }

  /* ================================================================== */
  /* 6. MESIN SLIDESHOW                                                  */
  /*                                                                     */
  /* Satu jam internal ("clock") menggerakkan semuanya. Jam ini berhenti */
  /* saat dijeda atau saat tab disembunyikan, sehingga timer, typewriter,*/
  /* dan galeri ikut berhenti bersamaan.                                 */
  /* ================================================================== */

  const story = {
    started: false,
    slides: [],
    index: 0,
    paused: false,
    scene: null,
    lastFrame: 0,

    begin(startIndex) {
      this.slides = window.STORY_CONFIG.slides;
      screens.show("stage");
      this.buildHud();
      player.render();
      this.paused = false;
      if (!this.started) {
        this.started = true;
        this.lastFrame = performance.now();
        requestAnimationFrame((now) => this.loop(now));
      }
      this.show(startIndex, true);
    },

    stop() {
      this.started = false;
      if (this.scene) this.scene.destroy();
      this.scene = null;
      $("#slides").replaceChildren();
    },

    buildHud() {
      $("#progress").replaceChildren(...this.slides.map(() => h("i", {}, h("b"))));
      $("#progress").setAttribute("aria-valuemax", this.slides.length);
      $("#btn-back").innerHTML = ICONS.back;
      $("#btn-next").innerHTML = ICONS.next;
      this.renderPause();
    },

    renderPause() {
      const button = $("#btn-pause");
      button.innerHTML = this.paused ? ICONS.play : ICONS.pause;
      button.setAttribute("aria-label", this.paused ? "Lanjutkan cerita" : "Jeda cerita");
      $("#stage").classList.toggle("is-paused", this.paused);
    },

    togglePause() {
      this.paused = !this.paused;
      this.renderPause();
    },

    next() {
      if (this.scene && this.scene.locked) {
        toast(this.scene.lockMessage || "Jawab dulu dong, dek 🥺");
        return;
      }
      if (this.index < this.slides.length - 1) this.show(this.index + 1);
    },

    back() {
      if (this.index > 0) this.show(this.index - 1);
    },

    show(index) {
      const config = this.slides[index];
      const renderer = RENDERERS[config.type];
      if (!renderer) {
        console.error(`Jenis slide tidak dikenal: ${config.type}`);
        if (index < this.slides.length - 1) this.show(index + 1);
        return;
      }

      const previous = this.scene;
      if (previous) previous.leave();

      this.index = index;
      if (this.paused) {
        this.paused = false; // pindah slide manual melanjutkan cerita
        this.renderPause();
      }
      memory.set("progress", index);

      const scene = new Scene(config, index);
      this.scene = scene;
      renderer(scene, config);
      scene.mount();
      this.renderHud(config);
      this.preload(index + 1);
      this.preload(index + 2);
    },

    renderHud(config) {
      const bars = $("#progress").children;
      for (let i = 0; i < bars.length; i++) {
        bars[i].firstChild.style.transform = `scaleX(${i < this.index ? 1 : 0})`;
        bars[i].classList.toggle("is-waiting", false);
      }
      $("#progress").setAttribute("aria-valuenow", this.index + 1);
      $("#chapter-label").textContent = `Chapter ${this.index + 1} of ${this.slides.length}`;
      $("#btn-back").disabled = this.index === 0;
      $("#btn-next").disabled = this.index === this.slides.length - 1;
      $("#stage").dataset.tone = config.tone || TONE_BY_TYPE[config.type] || "light";
    },

    preload(index) {
      const config = this.slides[index];
      if (!config) return;
      const { memories } = window.STORY_CONFIG;
      const images = config.image ? [config.image]
        : config.type === "reel" ? memories.map((m) => m.image)
        : config.type === "polaroids" ? memories.slice(0, config.count || 4).map((m) => m.image) : [];
      for (const src of images) new Image().src = src;
    },

    loop(now) {
      if (!this.started) return;
      const dt = Math.min(now - this.lastFrame, 100);
      this.lastFrame = now;
      const scene = this.scene;
      if (scene && !this.paused && !document.hidden) {
        scene.advance(dt);
        const bar = $("#progress").children[this.index];
        if (bar) {
          bar.firstChild.style.transform = `scaleX(${scene.progress()})`;
          bar.classList.toggle("is-waiting", scene.duration === Infinity);
        }
        if (scene === this.scene && scene.isFinished() && this.index < this.slides.length - 1) {
          this.show(this.index + 1);
        }
      }
      requestAnimationFrame((next) => this.loop(next));
    },
  };

  /** Satu slide yang sedang tampil, beserta jadwal kejadian di dalamnya. */
  class Scene {
    constructor(config, index) {
      this.config = config;
      this.index = index;
      this.clock = 0;
      this.duration = config.duration ?? Infinity;
      this.progressFrom = 0;
      this.locked = false;
      this.lockMessage = "";
      this.tasks = [];
      this.tickers = [];
      this.cleanups = [];
      this.dead = false;

      this.background = h("div", { class: "slide-bg" });
      this.canvas = h("canvas", { class: "ambient", "aria-hidden": "true" });
      this.body = h("div", { class: "slide-body" });
      this.scroller = h("div", { class: "slide-scroll" }, this.body);
      const kind = config.type === "question" ? "question" : config.type;
      this.root = h("section", { class: `slide slide--${kind} enter--${config.transition || "fade"}` }, this.background, this.canvas, this.scroller);

      /* Menggulir berarti sedang membaca: beri waktu tambahan. */
      this.scroller.addEventListener("scroll", () => {
        if (!this.autoScrolling) this.touch(5000);
      }, { passive: true });
    }

    /* --- dipakai oleh tampilan slide --- */
    add(...elements) { this.body.append(...elements); }
    at(ms, fn) { this.tasks.push({ time: this.clock + ms, fn }); }
    onTick(fn) { this.tickers.push(fn); }
    onCleanup(fn) { this.cleanups.push(fn); }
    /** Slide selesai `ms` milidetik dari sekarang. */
    finishIn(ms) {
      this.progressFrom = this.clock;
      this.duration = this.clock + ms;
    }
    /** Menghentikan timer sampai finishIn dipanggil, misalnya saat menunggu jawaban. */
    hold() {
      this.duration = Infinity;
      this.progressFrom = this.clock;
    }
    lock(message) { this.locked = true; this.lockMessage = message; }
    unlock() { this.locked = false; }
    /** Ada interaksi: pastikan masih tersisa waktu minimal `ms`. */
    touch(ms = 6000) {
      if (this.duration !== Infinity && this.duration - this.clock < ms) this.duration = this.clock + ms;
    }
    ambient(kinds, density) {
      this.ambientFx = new Ambient(this.canvas, kinds, density);
      this.onMounted = () => this.ambientFx.start();
      this.onCleanup(() => this.ambientFx.stop());
    }

    /* --- dipakai oleh mesin --- */
    mount() {
      $("#slides").append(this.root);
      requestAnimationFrame(() => this.root.classList.add("is-on"));
      if (this.onMounted) this.onMounted();
    }
    advance(dt) {
      this.clock += dt;
      const due = this.tasks.filter((task) => task.time <= this.clock);
      if (due.length) {
        this.tasks = this.tasks.filter((task) => task.time > this.clock);
        for (const task of due) task.fn();
      }
      for (const ticker of this.tickers) ticker(this.clock);
    }
    progress() {
      if (this.duration === Infinity) return 0;
      const span = this.duration - this.progressFrom;
      return span <= 0 ? 1 : clamp((this.clock - this.progressFrom) / span, 0, 1);
    }
    isFinished() {
      return this.clock >= this.duration;
    }
    leave() {
      this.tasks = [];
      this.tickers = [];
      this.dead = true;
      this.root.classList.add("is-leaving");
      this.root.setAttribute("aria-hidden", "true");
      this.root.inert = true;
      setTimeout(() => this.destroy(), REDUCED_MOTION ? 250 : 1100);
    }
    destroy() {
      for (const cleanup of this.cleanups) cleanup();
      this.cleanups = [];
      this.root.remove();
    }
  }

  const TONE_BY_TYPE = { portrait: "dark", loves: "rose", appreciation: "light", reel: "dark", future: "dark", cake: "dark", final: "dark", numbers: "dark" };

  /* Efek parallax: elemen .depth bergeser mengikuti kursor (atau kemiringan HP di Android). */
  function setupParallax() {
    if (REDUCED_MOTION) return;
    const stage = $("#stage");
    const apply = (x, y) => {
      stage.style.setProperty("--px", x.toFixed(3));
      stage.style.setProperty("--py", y.toFixed(3));
    };
    if (window.matchMedia("(pointer: fine)").matches) {
      stage.addEventListener("pointermove", (event) => {
        apply(event.clientX / window.innerWidth - 0.5, event.clientY / window.innerHeight - 0.5);
      }, { passive: true });
    } else {
      window.addEventListener("deviceorientation", (event) => {
        if (event.gamma === null) return;
        apply(clamp(event.gamma / 45, -0.5, 0.5), clamp((event.beta - 45) / 60, -0.5, 0.5));
      }, { passive: true });
    }
  }

  /* ================================================================== */
  /* 7. TAMPILAN SETIAP JENIS SLIDE                                      */
  /* ================================================================== */

  /** Foto dengan placeholder otomatis kalau file-nya belum ada. */
  function photo(src, alt, { className = "", position } = {}) {
    const frame = h("div", { class: `photo ${className}` });
    if (!src) {
      frame.append(photoPlaceholder(""));
      return frame;
    }
    const image = h("img", { alt: alt || "Foto kenangan", decoding: "async", draggable: "false" });
    if (position) image.style.objectPosition = position;
    image.addEventListener("error", () => {
      frame.classList.add("is-missing");
      image.replaceWith(photoPlaceholder(src));
    });
    image.src = src;
    frame.append(image);
    return frame;
  }

  function photoPlaceholder(src) {
    const fileName = src.split("/").pop();
    return h("div", { class: "photo-placeholder" },
      h("span", { class: "photo-placeholder-icon", svg: ICONS.heart, "aria-hidden": "true" }),
      h("span", { class: "photo-placeholder-title", text: "Foto kita, sebentar lagi di sini" }),
      fileName && h("span", { class: "photo-placeholder-file", text: fileName }));
  }

  /** Foto utuh di atas salinannya yang diburamkan, sehingga tidak ada bagian yang terpotong. */
  function cinematicPhoto(src, alt) {
    const wrap = h("div", { class: "cinema" });
    const backdrop = h("div", { class: "cinema-backdrop" });
    const front = photo(src, alt, { className: "cinema-photo" });
    const probe = front.querySelector("img");
    if (probe) {
      const blurred = h("img", { alt: "", "aria-hidden": "true" });
      blurred.src = src;
      blurred.addEventListener("error", () => blurred.remove());
      backdrop.append(blurred);
    }
    wrap.append(backdrop, front);
    return wrap;
  }

  const RENDERERS = {
    /* Pembukaan: angka 24 besar, confetti, dan balon */
    welcome(scene, config) {
      scene.ambient(["balloons"]);
      scene.add(
        h("div", { class: "welcome-numeral depth", "aria-hidden": "true", text: "24" }),
        h("h1", { class: "r r-blur welcome-title", delay: 300, text: config.title }),
        h("p", { class: "r r-up welcome-sub", delay: 1300, text: config.subtitle })
      );
      scene.at(400, () => confetti.burst(90));
    },

    /* Foto utuh dengan zoom pelan */
    portrait(scene, config) {
      scene.background.append(cinematicPhoto(config.image, "Foto Cerinova"));
      scene.add(h("p", { class: "r r-blur portrait-text", delay: 1400, text: config.text }));
    },

    /* C-E-R-I-N-O-V-A, satu huruf satu kalimat */
    acrostic(scene, config) {
      scene.ambient(["petals"], 0.6);
      scene.add(
        h("h2", { class: "r r-up acrostic-title", text: config.title }),
        h("ol", { class: "acrostic" }, config.lines.map((line, i) =>
          h("li", { class: "r r-left", delay: 900 + i * 1050 },
            h("span", { class: "acrostic-letter", text: line.letter }),
            h("span", { class: "acrostic-text", text: line.text }))))
      );
    },

    /* Foto ditempel selotip di samping cerita */
    story(scene, config) {
      scene.add(h("div", { class: "story-layout" },
        h("figure", { class: "story-photo depth r r-drop", delay: 200 },
          photo(config.image, config.caption),
          config.caption && h("figcaption", { text: config.caption })),
        h("div", { class: "story-copy" },
          h("h2", { class: "r r-up", delay: 900, text: config.title }),
          h("p", { class: "r r-up", delay: 1500, text: config.text }))));
    },

    /* Satu hal per layar */
    loves(scene, config) {
      const itemTime = config.itemDuration || 4000;
      scene.finishIn(itemTime * config.items.length + 800);
      const stack = h("div", { class: "loves-stack" });
      const dots = h("div", { class: "loves-dots", "aria-hidden": "true" }, config.items.map(() => h("i")));
      scene.add(h("p", { class: "r r-fade loves-kicker", text: "Things I love about you" }), stack, dots);
      config.items.forEach((item, i) => {
        scene.at(400 + i * itemTime, () => {
          stack.replaceChildren(h("div", { class: "loves-item" },
            h("p", { class: "loves-text", text: item.text }),
            item.note && h("p", { class: "loves-note", text: item.note })));
          [...dots.children].forEach((dot, d) => dot.classList.toggle("is-on", d <= i));
        });
      });
    },

    /* Polaroid yang jatuh ke meja; ketuk untuk mengangkat */
    polaroids(scene, config) {
      const { memories } = window.STORY_CONFIG;
      const tilts = [-5, 3.5, 4.5, -3, 2];
      const cards = memories.slice(0, config.count || 4).map((memoryItem, i) => {
        const card = h("button", { type: "button", class: "polaroid r r-drop", delay: 500 + i * 650, "aria-pressed": "false" },
          photo(memoryItem.image, memoryItem.caption, { position: memoryItem.position }),
          h("span", { class: "polaroid-caption", text: memoryItem.caption }));
        card.style.setProperty("--tilt", `${tilts[i % tilts.length]}deg`);
        card.addEventListener("click", () => {
          const lifted = card.classList.toggle("is-lifted");
          card.setAttribute("aria-pressed", String(lifted));
          cards.filter((other) => other !== card).forEach((other) => {
            other.classList.remove("is-lifted");
            other.setAttribute("aria-pressed", "false");
          });
          scene.touch(8000);
        });
        return card;
      });
      scene.add(h("h2", { class: "r r-up polaroids-title", text: config.title }), h("div", { class: "polaroids depth" }, cards));
    },

    /* Pesan panjang, satu paragraf menyala setiap kali */
    appreciation(scene, config) {
      const time = config.paragraphDuration || 7500;
      scene.finishIn(time * config.paragraphs.length + 1500);
      scene.ambient(["petals"], 0.5);
      const paragraphs = config.paragraphs.map((text) => h("p", { class: "appreciation-line", text }));
      scene.add(h("h2", { class: "r r-up appreciation-title", text: config.title }), h("div", { class: "appreciation" }, paragraphs));
      paragraphs.forEach((paragraph, i) => {
        scene.at(800 + i * time, () => {
          paragraphs.forEach((other, o) => {
            other.classList.toggle("is-current", o === i);
            other.classList.toggle("is-past", o < i);
          });
        });
      });
    },

    /* Daftar impian yang bisa dicentang */
    bucket(scene, config) {
      const saved = memory.get("bucket", {});
      const items = config.items.map((text, i) => {
        const checkbox = h("input", { type: "checkbox", id: `bucket-${i}` });
        checkbox.checked = Boolean(saved[text]);
        checkbox.addEventListener("change", () => {
          memory.patch("bucket", text, checkbox.checked || undefined);
          scene.touch(7000);
        });
        return h("li", { class: "r r-left", delay: 900 + i * 900 },
          checkbox,
          h("label", { for: `bucket-${i}` },
            h("span", { class: "bucket-check", svg: ICONS.check, "aria-hidden": "true" }),
            h("span", { class: "bucket-text", text })));
      });
      scene.add(h("div", { class: "bucket-page" },
        h("h2", { class: "r r-up", text: config.title }),
        h("p", { class: "r r-fade bucket-hint", delay: 500, text: config.hint }),
        h("ul", { class: "bucket" }, items)));
    },

    /* Voucher lucu: yang diklaim tercatat di answers.txt */
    vouchers(scene, config) {
      const claimed = memory.get("vouchers", {});
      const cards = config.items.map((item, i) => {
        const button = h("button", { class: "voucher-claim", type: "button", text: claimed[item.title] ? "Diklaim ❤️" : "Klaim" });
        button.disabled = Boolean(claimed[item.title]);
        const card = h("article", { class: `voucher r r-drop${claimed[item.title] ? " is-claimed" : ""}`, delay: 700 + i * 500 },
          h("div", { class: "voucher-copy" },
            h("h3", { text: item.title }),
            h("p", { text: item.note })),
          button);
        button.addEventListener("click", async () => {
          scene.touch(8000);
          button.disabled = true;
          button.textContent = "...";
          const saved = await sendAnswer(config.questionId, item.title);
          if (saved) {
            memory.patch("vouchers", item.title, true);
            button.textContent = "Diklaim ❤️";
            card.classList.add("is-claimed");
            confetti.burst(25);
          } else {
            button.disabled = false;
            button.textContent = "Klaim";
          }
        });
        return card;
      });
      scene.add(
        h("h2", { class: "r r-up vouchers-title", text: config.title }),
        h("p", { class: "r r-fade vouchers-hint", delay: 400, text: config.hint }),
        h("div", { class: "vouchers" }, cards)
      );
    },

    /* Angka besar yang menghitung naik */
    numbers(scene, config) {
      const format = (n) => new Intl.NumberFormat("id-ID").format(n);
      const rows = config.items.map((item, i) => {
        const value = h("span", { class: "number-value", text: REDUCED_MOTION ? format(item.value) : "0" });
        if (!REDUCED_MOTION) {
          const start = 700 + i * 1600;
          const span = 1500;
          scene.onTick((clock) => {
            const t = clamp((clock - start) / span, 0, 1);
            if (clock < start || value.dataset.done) return;
            value.textContent = format(Math.round(item.value * (1 - Math.pow(1 - t, 3))));
            if (t === 1) value.dataset.done = "1";
          });
        }
        return h("li", { class: "r r-up", delay: 600 + i * 1600 }, value, h("span", { class: "number-label", text: item.label }));
      });
      scene.ambient(["stars"], 0.5);
      scene.add(
        h("h2", { class: "r r-up numbers-title", text: config.title }),
        h("ul", { class: "numbers" }, rows),
        h("p", { class: "r r-blur numbers-closing", delay: 6200, text: config.closing })
      );
    },

    /* 24 harapan, enam per halaman */
    wishes(scene, config) {
      const PER_PAGE = 6;
      const pageTime = config.pageDuration || 5500;
      const pageCount = Math.ceil(config.items.length / PER_PAGE);
      scene.finishIn(pageTime * pageCount + 500);
      const list = h("ol", { class: "wishes" });
      const counter = h("p", { class: "wishes-count", "aria-hidden": "true" });
      scene.add(h("h2", { class: "r r-up wishes-title", text: config.title }), list, counter);
      for (let page = 0; page < pageCount; page++) {
        scene.at(500 + page * pageTime, () => {
          const first = page * PER_PAGE;
          const items = config.items.slice(first, first + PER_PAGE);
          list.replaceChildren(...items.map((text, i) =>
            h("li", { class: "r r-up", delay: i * 220 },
              h("span", { class: "wish-number", text: String(first + i + 1) }),
              h("span", { class: "wish-text", text }))));
          counter.textContent = `${first + 1} sampai ${first + items.length} dari ${config.items.length}`;
        });
      }
    },

    /* Galeri sinematik: tiap foto zoom pelan, dengan caption dan tanggal */
    reel(scene, config) {
      const { memories } = window.STORY_CONFIG;
      const time = config.photoDuration || 6000;
      scene.finishIn(time * Math.max(memories.length, 1) + 600);
      memories.forEach((memoryItem, i) => {
        scene.at(i * time, () => {
          const old = [...scene.background.children];
          const frame = h("div", { class: `reel-frame reel-frame--${i % 2 ? "b" : "a"}` },
            cinematicPhoto(memoryItem.image, memoryItem.caption));
          scene.background.append(frame);
          scene.body.replaceChildren(h("div", { class: "reel-caption" },
            h("p", { class: "reel-caption-text", text: memoryItem.caption }),
            memoryItem.date && h("p", { class: "reel-caption-date", text: memoryItem.date })));
          setTimeout(() => old.forEach((element) => element.remove()), 1500);
        });
      });
    },

    /* Surat dengan efek mengetik; ketuk kertasnya untuk menampilkan semua */
    letter(scene, config) {
      const text = window.STORY_CONFIG.letter;
      const speed = config.typingSpeed || 32;
      const hold = config.holdAfterTyping ?? 12000;
      const typed = h("span", { class: "letter-typed", "aria-hidden": "true" });
      const caret = h("span", { class: "letter-caret", "aria-hidden": "true" });
      const paper = h("article", { class: "letter-paper r r-rise", delay: 200, "aria-label": text }, typed, caret);
      scene.add(h("h2", { class: "r r-fade letter-title", text: config.title }), paper);

      if (REDUCED_MOTION) {
        typed.textContent = text;
        caret.remove();
        scene.finishIn(text.length * 45 + hold);
        return;
      }

      const startAt = 1500;
      let finished = false;
      scene.finishIn(startAt + text.length * speed + hold);

      const finish = () => {
        finished = true;
        typed.textContent = text;
        caret.remove();
      };
      paper.addEventListener("click", () => {
        if (finished) return;
        finish();
        scene.finishIn(hold + 10000); // ditampilkan sekaligus, jadi perlu waktu baca lebih lama
      });
      let shown = 0;
      scene.onTick((clock) => {
        if (finished || clock < startAt) return;
        const count = Math.min(Math.floor((clock - startAt) / speed), text.length);
        if (count === shown) return;
        shown = count;
        typed.textContent = text.slice(0, count);
        // Jaga baris yang sedang diketik tetap terlihat di layar kecil.
        scene.autoScrolling = true;
        scene.scroller.scrollTop = scene.scroller.scrollHeight;
        requestAnimationFrame(() => { scene.autoScrolling = false; });
        if (count === text.length) finish();
      });
    },

    /* Amplop kecil berisi pesan untuk hari-hari tertentu */
    openwhen(scene, config) {
      const note = h("div", { class: "openwhen-note", role: "status" });
      const envelopes = config.items.map((item, i) => {
        const button = h("button", { type: "button", class: "openwhen-env r r-drop", delay: 700 + i * 450 },
          h("span", { class: "openwhen-seal", svg: ICONS.heart, "aria-hidden": "true" }),
          h("span", { class: "openwhen-label", text: item.label }));
        button.addEventListener("click", () => {
          envelopes.forEach((other) => other.classList.toggle("is-active", other === button));
          note.replaceChildren(h("p", { class: "openwhen-text", text: item.note }));
          scene.touch(11000);
          note.scrollIntoView({ block: "nearest", behavior: REDUCED_MOTION ? "auto" : "smooth" });
        });
        return button;
      });
      scene.add(
        h("h2", { class: "r r-up openwhen-title", text: config.title }),
        h("p", { class: "r r-fade openwhen-hint", delay: 400, text: config.hint }),
        h("div", { class: "openwhen" }, envelopes),
        note
      );
    },

    /* Langit malam */
    future(scene, config) {
      scene.ambient(["stars"], 1.1);
      scene.background.append(
        h("span", { class: "shooting-star" }),
        h("span", { class: "shooting-star shooting-star--late" }),
        h("span", { class: "horizon depth" })
      );
      scene.add(h("p", { class: "r r-blur future-text", delay: 900, text: config.text }));
    },

    /* Kue dengan 24 lilin */
    cake(scene, config) {
      scene.hold();
      scene.lock("Tiup lilinnya dulu dong, dek 🎂");
      const cake = h("div", { class: "cake r r-rise", delay: 400, svg: buildCakeSvg(), role: "img", "aria-label": "Kue ulang tahun dengan 24 lilin menyala" });
      const title = h("h2", { class: "r r-blur cake-title", delay: 1100, text: config.title });
      const button = h("button", { class: "btn btn--gold r r-up", delay: 1900, type: "button", text: config.button });
      const flames = () => [...cake.querySelectorAll(".candle")];

      button.addEventListener("click", () => {
        button.disabled = true;
        scene.root.classList.add("is-blowing");
        const order = flames().sort((a, b) => Number(a.dataset.x) - Number(b.dataset.x));
        const step = REDUCED_MOTION ? 0 : 45;
        order.forEach((candle, i) => scene.at(i * step, () => candle.classList.add("is-out")));
        scene.at(order.length * step + 350, () => {
          scene.root.classList.add("is-wished");
          title.textContent = config.afterTitle;
          button.classList.add("is-gone");
          cake.setAttribute("aria-label", "Kue ulang tahun, semua lilin sudah padam");
          confetti.burst(170);
          scene.unlock();
          scene.finishIn(config.holdAfterBlow ?? 9000);
        });
      });
      scene.add(title, cake, button);
    },

    /* Penutup */
    final(scene, config) {
      scene.hold();
      scene.ambient(["petals"], 0.7);
      const actions = h("div", { class: "r r-fade final-actions", delay: 7200 },
        h("button", { class: "btn btn--ghost", type: "button", text: config.replay, onclick: () => story.show(0) }),
        h("button", { class: "link-btn", type: "button", text: config.logout, onclick: logout }));
      scene.add(
        h("div", { class: "final-ornament r r-fade", "aria-hidden": "true", svg: ICONS.heart }),
        h("h1", { class: "r r-blur final-title", delay: 500, text: config.title }),
        h("p", { class: "r r-up final-text", delay: 2000, text: config.text }),
        h("p", { class: "r r-up final-sign", delay: 3600 },
          h("span", { text: config.signoff }),
          h("strong", { text: config.signature })),
        h("p", { class: "r r-fade final-next", delay: 5400, text: config.nextChapter }),
        actions
      );
      scene.at(600, () => confetti.burst(70));
    },

    question: renderQuestion,
  };

  async function logout() {
    try {
      await post("/api/logout", {});
    } catch {
      /* tetap kembali ke halaman login */
    }
    story.stop();
    if (player.audio) player.audio.pause();
    csrfToken = "";
    memory.set("progress", 0);
    showLogin();
  }

  function buildCakeSvg() {
    /* Posisi 24 lilin: 14 di lingkar luar, 10 di lingkar dalam. */
    const candles = [];
    const ring = (count, rx, ry, offset) => {
      for (let i = 0; i < count; i++) {
        const a = (i / count) * Math.PI * 2 + offset;
        candles.push({ x: 180 + Math.cos(a) * rx, y: 118 + Math.sin(a) * ry });
      }
    };
    ring(14, 86, 21, 0.2);
    ring(10, 48, 10.5, 0.5);
    candles.sort((a, b) => a.y - b.y);

    const candleSvg = candles.map((c, i) => {
      const x = c.x.toFixed(1);
      const top = (c.y - 27).toFixed(1);
      const stripe = i % 2 ? "#F4DDE1" : "#D6B77A";
      return `<g class="candle" data-x="${x}" data-i="${i}">
        <circle class="candle-glow" cx="${x}" cy="${(c.y - 36).toFixed(1)}" r="14" fill="url(#flameGlow)"/>
        <rect x="${(c.x - 2.2).toFixed(1)}" y="${top}" width="4.4" height="27" rx="1.6" fill="${stripe}"/>
        <path class="candle-smoke" d="M${x} ${top}c-3-6 3-9 0-15s3-9 0-14" fill="none" stroke="#FFF8F0" stroke-width="1.2" stroke-linecap="round"/>
        <path class="candle-flame" d="M${x} ${(c.y - 42).toFixed(1)}c3.6 4.8 4.6 7.3 4.6 9.3a4.6 4.6 0 0 1-9.2 0c0-2 1-4.5 4.6-9.3Z" fill="url(#flameFill)"/>
      </g>`;
    }).join("");

    return `<svg viewBox="0 0 360 330" aria-hidden="true">
      <defs>
        <radialGradient id="flameGlow"><stop offset="0" stop-color="#FFE9B8" stop-opacity=".85"/><stop offset="1" stop-color="#FFE9B8" stop-opacity="0"/></radialGradient>
        <linearGradient id="flameFill" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#FFF3C9"/><stop offset=".55" stop-color="#F5C670"/><stop offset="1" stop-color="#E08F58"/></linearGradient>
        <linearGradient id="tierTop" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#E9C6CA"/><stop offset=".45" stop-color="#F9ECEC"/><stop offset="1" stop-color="#D8A7A7"/></linearGradient>
        <linearGradient id="tierBottom" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#8C4F5E"/><stop offset=".45" stop-color="#A9697A"/><stop offset="1" stop-color="#763D4B"/></linearGradient>
      </defs>
      <ellipse cx="180" cy="306" rx="170" ry="22" fill="#D6B77A"/>
      <ellipse cx="180" cy="300" rx="170" ry="22" fill="#FFF8F0"/>
      <path d="M40 212v80c0 12 62 22 140 22s140-10 140-22v-80Z" fill="url(#tierBottom)"/>
      <ellipse cx="180" cy="212" rx="140" ry="28" fill="#F4DDE1"/>
      <path d="M40 212c0 10 8 16 13 16s6 22 13 22 7-16 14-14 5 30 14 30 8-22 15-20 6 12 13 12 7-8 13-8c7 0 7 26 16 26s8-20 15-20 6 10 14 10 8-14 15-14 6 24 15 24 7-22 14-22 6 10 13 10 8-20 15-20 6 8 8-16Z" fill="#F4DDE1"/>
      <path d="M92 118v84c0 11 39 20 88 20s88-9 88-20v-84Z" fill="url(#tierTop)"/>
      <path d="M92 174c0 10 39 19 88 19s88-9 88-19" fill="none" stroke="#D6B77A" stroke-width="2.5"/>
      <g fill="#D6B77A">${[110, 133, 156, 180, 204, 227, 250].map((x, i) => `<circle cx="${x}" cy="${[182, 188, 191, 193, 191, 188, 182][i]}" r="2.6"/>`).join("")}</g>
      <ellipse cx="180" cy="118" rx="88" ry="22" fill="#FFF8F0"/>
      <ellipse cx="180" cy="118" rx="88" ry="22" fill="none" stroke="#E9C6CA" stroke-width="2"/>
      ${candleSvg}
    </svg>`;
  }

  /* ================================================================== */
  /* 8. PERTANYAAN                                                       */
  /* ================================================================== */

  /** Mengirim jawaban. Mengembalikan true kalau server sudah benar-benar menyimpannya. */
  async function sendAnswer(questionId, answer) {
    try {
      const { ok, status, data } = await post("/api/answers", { questionId, answer });
      if (ok) return true;
      if (status === 401) {
        toast("Sesinya habis, dek. Login lagi ya, jawabanmu masih aman.", "error");
        story.stop();
        showLogin();
        return false;
      }
      toast(data.error || "Jawabannya belum tersimpan. Coba kirim lagi ya.", "error");
      return false;
    } catch {
      toast("Koneksinya lagi putus. Jawabanmu masih ada di sini, coba kirim lagi ya.", "error");
      return false;
    }
  }

  const QUESTION_ART = {
    ramen: `<svg viewBox="0 0 240 170" class="ramen-art" aria-hidden="true">
      <g class="steam" fill="none" stroke="#D8A7A7" stroke-width="3.5" stroke-linecap="round">
        <path d="M84 56c-8-10 8-16 0-27"/><path d="M120 52c-8-11 8-18 0-30"/><path d="M156 56c-8-10 8-16 0-27"/>
      </g>
      <ellipse cx="120" cy="82" rx="96" ry="21" fill="#FFF8F0" stroke="#763D4B" stroke-width="3"/>
      <ellipse cx="120" cy="83" rx="85" ry="15" fill="#E9B77F"/>
      <g fill="none" stroke="#F5DFA8" stroke-width="3" stroke-linecap="round">
        <path d="M54 84c14-9 22 7 36 0s22 6 34 0"/><path d="M68 90c14-7 24 6 38 0s20 3 30 0"/><path d="M122 78c12-6 20 5 32 0s16 2 26 2"/>
      </g>
      <circle cx="154" cy="82" r="11" fill="#FFF8F0"/><circle cx="154" cy="82" r="5.5" fill="#E9A33E"/>
      <circle cx="88" cy="79" r="10" fill="#FFF8F0" stroke="#F4DDE1" stroke-width="1"/><path d="M84 79c1.5-4 7-4 8 0s-6 4-4 1" fill="none" stroke="#D8A7A7" stroke-width="2" stroke-linecap="round"/>
      <path d="M26 88c6 40 40 66 94 66s88-26 94-66c-18 13-56 20-94 20s-76-7-94-20Z" fill="#763D4B"/>
      <path d="M92 154h56l-5 11H97Z" fill="#5E2F3B"/>
      <path d="M46 116c10 12 22 20 36 25" fill="none" stroke="#D6B77A" stroke-width="3" stroke-linecap="round"/>
      <path d="M160 22 222 72M172 16l60 50" stroke="#D6B77A" stroke-width="4" stroke-linecap="round"/>
    </svg>`,
    bus: `<svg viewBox="0 0 120 56" class="ticket-bus" aria-hidden="true">
      <rect x="4" y="6" width="112" height="38" rx="9" fill="#763D4B"/>
      <rect x="12" y="13" width="17" height="14" rx="2.5" fill="#FFF8F0"/><rect x="33" y="13" width="17" height="14" rx="2.5" fill="#FFF8F0"/><rect x="54" y="13" width="17" height="14" rx="2.5" fill="#FFF8F0"/><rect x="75" y="13" width="17" height="14" rx="2.5" fill="#FFF8F0"/>
      <path d="M97 13h10c4 0 6 3 6 8v6H97Z" fill="#F4DDE1"/>
      <path d="M43 22.5c-2.5-1.7-3.5-3-3.5-4.2 0-1 .8-1.7 1.7-1.7.8 0 1.4.4 1.8 1.2.4-.8 1-1.2 1.8-1.2.9 0 1.7.7 1.7 1.7 0 1.2-1 2.5-3.5 4.2Z" fill="#763D4B" transform="translate(-1.5 -1)"/>
      <rect x="4" y="33" width="112" height="3" fill="#D6B77A"/>
      <circle cx="30" cy="45" r="8" fill="#3E1F28"/><circle cx="30" cy="45" r="3.2" fill="#D6B77A"/><circle cx="90" cy="45" r="8" fill="#3E1F28"/><circle cx="90" cy="45" r="3.2" fill="#D6B77A"/>
    </svg>`,
  };

  function responseFor(question, answer) {
    if (question.type === "radio") {
      const option = question.options.find((item) => (typeof item === "string" ? item : item.label) === answer);
      if (option && typeof option !== "string" && option.response) return option.response;
    }
    return question.response || "Makasih ya, dek ❤️";
  }

  function renderQuestion(scene, config) {
    const question = window.STORY_CONFIG.questions.find((item) => item.id === config.questionId);
    if (!question) {
      console.error(`Pertanyaan "${config.questionId}" tidak ada di config.js`);
      scene.finishIn(0);
      return;
    }
    const look = question.look || "note";
    scene.root.classList.add(`look--${look}`);
    config.tone = look === "film" ? "dark" : "light";

    const sent = memory.get("answers", {});
    if (sent[question.id] !== undefined) showAnswered(scene, question, sent[question.id]);
    else showForm(scene, question);
  }

  function showForm(scene, question, startValue) {
    scene.hold();
    scene.lock("Jawab dulu dong, dek 🥺");
    const draftValue = startValue ?? memory.get("drafts", {})[question.id] ?? "";

    const errorText = h("p", { class: "q-error", role: "alert" });
    const title = h("h2", { class: "q-title", id: `title-${question.id}`, text: question.title });

    let readValue;
    let inputArea;
    let submitButton = h("button", { class: "btn q-submit", type: "submit", text: question.submitLabel || "Kirim jawaban" });

    const setBusy = (busy) => {
      form.querySelectorAll("button, input, textarea").forEach((element) => { element.disabled = busy; });
      if (submitButton) submitButton.textContent = busy ? "Menyimpan..." : question.submitLabel || "Kirim jawaban";
    };

    const showError = (message) => {
      errorText.textContent = message;
      form.classList.remove("shake");
      void form.offsetWidth;
      form.classList.add("shake");
    };

    const submit = async (rawValue) => {
      const value = (rawValue ?? readValue()).trim();
      if (!value) {
        showError(question.type === "radio" ? "Pilih salah satu dulu, dek." : "Diisi dulu dong, dek.");
        return;
      }
      if (question.maxWords && value.split(/\s+/).length > question.maxWords) {
        showError("Satu kata aja, dek.");
        return;
      }
      const maxLength = question.maxLength || (question.type === "textarea" ? 2000 : question.type === "date" ? 100 : 200);
      if (value.length > maxLength) {
        showError("Jawabannya kepanjangan, dek.");
        return;
      }
      errorText.textContent = "";
      setBusy(true);
      const saved = await sendAnswer(question.id, value);
      if (scene.dead) return;
      setBusy(false);
      if (!saved) return;
      const shown = question.type === "date" ? describeDate(value) : value;
      memory.patch("answers", question.id, shown);
      memory.patch("drafts", question.id, undefined);
      showResponse(scene, question, value);
    };

    const saveDraft = (value) => memory.patch("drafts", question.id, value || undefined);

    if (question.type === "radio") {
      submitButton = null;
      readValue = () => "";
      inputArea = h("div", { class: "q-options", role: "group", "aria-labelledby": title.id },
        question.options.map((option, i) => {
          const label = typeof option === "string" ? option : option.label;
          return h("button", { class: `q-option q-option--${i % 3}`, type: "button", text: label, onclick: () => submit(label) });
        }));
    } else if (question.type === "textarea") {
      const textarea = h("textarea", { class: "q-input", rows: "5", placeholder: question.placeholder || "", maxlength: question.maxLength || 2000, "aria-labelledby": title.id });
      textarea.value = draftValue;
      textarea.addEventListener("input", () => saveDraft(textarea.value));
      readValue = () => textarea.value;
      inputArea = textarea;
    } else if (question.type === "date") {
      ({ inputArea, readValue } = buildDateInput(question, title.id, draftValue, saveDraft));
    } else {
      const input = h("input", { class: "q-input", type: "text", placeholder: question.placeholder || "", maxlength: question.maxLength || 200, autocomplete: "off", "aria-labelledby": title.id });
      input.value = draftValue;
      input.addEventListener("input", () => saveDraft(input.value));
      readValue = () => input.value;
      inputArea = input;
    }

    const art = buildQuestionArt(question);
    const form = h("form", { class: "q-card r r-rise", delay: 200, novalidate: true }, art, title, inputArea, errorText, submitButton);
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      submit();
    });
    if (question.type === "date") form.classList.add("q-card--date");

    scene.body.replaceChildren(form);
    if (question.look === "film") scene.background.append(h("span", { class: "film-glow" }));
  }

  /** Halaman kalender: tanggal yang dipilih langsung muncul besar di kertasnya. */
  function buildDateInput(question, titleId, draftValue, saveDraft) {
    const today = new Date();
    const maxDate = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, "0")}-${String(today.getDate()).padStart(2, "0")}`;
    const isDraftDate = /^\d{4}-\d{2}-\d{2}$/.test(draftValue);
    let usingText = Boolean(draftValue) && !isDraftDate;

    const dateInput = h("input", { class: "q-input", type: "date", max: maxDate, "aria-labelledby": titleId });
    if (isDraftDate) dateInput.value = draftValue;
    const textInput = h("input", { class: "q-input", type: "text", placeholder: question.placeholder || "", maxlength: "100", autocomplete: "off", "aria-labelledby": titleId, hidden: usingText ? undefined : true });
    if (usingText) textInput.value = draftValue;
    dateInput.hidden = usingText;

    const dayText = h("span", { class: "calendar-day", text: "?" });
    const monthText = h("span", { class: "calendar-month", text: "Tanggal berapa, ya?" });
    const page = h("div", { class: "calendar-page", "aria-hidden": "true" },
      h("span", { class: "calendar-rings" }, h("i"), h("i")),
      h("span", { class: "calendar-head", text: "Hari pertama kita" }),
      dayText, monthText);

    const update = () => {
      if (!usingText && dateInput.value) {
        const [year, month, day] = dateInput.value.split("-").map(Number);
        dayText.textContent = day;
        monthText.textContent = `${MONTHS[month - 1]} ${year}`;
      } else if (usingText && textInput.value.trim()) {
        dayText.textContent = "❤";
        monthText.textContent = textInput.value.trim();
      } else {
        dayText.textContent = "?";
        monthText.textContent = "Tanggal berapa, ya?";
      }
    };
    update();
    dateInput.addEventListener("input", () => { saveDraft(dateInput.value); update(); });
    textInput.addEventListener("input", () => { saveDraft(textInput.value); update(); });

    const switcher = h("button", { class: "link-btn q-switch", type: "button", text: usingText ? "Pilih dari kalender aja" : "Lupa tanggal pastinya? Tulis sendiri aja" });
    switcher.addEventListener("click", () => {
      usingText = !usingText;
      dateInput.hidden = usingText;
      textInput.hidden = !usingText;
      switcher.textContent = usingText ? "Pilih dari kalender aja" : "Lupa tanggal pastinya? Tulis sendiri aja";
      (usingText ? textInput : dateInput).focus();
      update();
    });

    return {
      inputArea: h("div", { class: "q-date" }, page, dateInput, textInput, switcher),
      readValue: () => (usingText ? textInput.value : dateInput.value),
    };
  }

  const MONTHS = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"];

  function describeDate(value) {
    const match = value.match(/^(\d{4})-(\d{2})-(\d{2})$/);
    return match ? `${Number(match[3])} ${MONTHS[Number(match[2]) - 1]} ${match[1]}` : value;
  }

  function buildQuestionArt(question) {
    switch (question.look) {
      case "ramen":
        return h("div", { class: "q-art", svg: QUESTION_ART.ramen });
      case "ticket":
        return h("div", { class: "ticket-head", "aria-hidden": "true" },
          h("div", { class: "ticket-route" },
            h("span", { class: "ticket-city" }, h("small", { text: "Dari" }), h("b", { text: "Sini" })),
            h("span", { class: "ticket-road", svg: QUESTION_ART.bus }),
            h("span", { class: "ticket-city" }, h("small", { text: "Ke" }), h("b", { text: "Jogja" }))),
          h("div", { class: "ticket-meta" },
            h("span", {}, h("small", { text: "Penumpang" }), h("b", { text: "Cerin & Mas" })),
            h("span", {}, h("small", { text: "Kursi" }), h("b", { text: "Sebelahan" })),
            h("span", {}, h("small", { text: "Berangkat" }), h("b", { text: "Kapan-kapan" }))));
      case "planner":
        return h("div", { class: "planner-head", "aria-hidden": "true" },
          h("span", { class: "planner-day", text: "Satu hari full" }),
          h("span", { class: "planner-sub", text: "07.00 sampai habis" }));
      case "film":
        return h("div", { class: "film-count", "aria-hidden": "true", text: "Rewind" });
      case "oneword":
        return h("div", { class: "oneword-mark", "aria-hidden": "true", text: "“" });
      default:
        return null;
    }
  }

  function showResponse(scene, question, value) {
    scene.unlock();
    scene.finishIn(question.responseDuration || 5500);
    confetti.burst(30);
    scene.body.replaceChildren(h("div", { class: "q-response" },
      h("span", { class: "q-response-heart", svg: ICONS.heart, "aria-hidden": "true" }),
      h("p", { class: "q-response-text", text: responseFor(question, value) })));
  }

  /** Dibuka lagi setelah dijawab: jawaban lama tetap terlihat dan boleh ditambah. */
  function showAnswered(scene, question, previous) {
    scene.unlock();
    scene.finishIn(7000);
    const change = h("button", { class: "link-btn", type: "button", text: "Mau jawab lagi", onclick: () => showForm(scene, question) });
    scene.body.replaceChildren(h("div", { class: "q-answered r r-rise" },
      h("p", { class: "q-answered-title", text: question.title }),
      h("p", { class: "q-answered-label", text: "Kamu jawab:" }),
      h("blockquote", { class: "q-answered-text", text: previous }),
      change));
  }

  /* ================================================================== */
  /* MULAI                                                               */
  /* ================================================================== */

  function setupControls() {
    $("#btn-pause").addEventListener("click", () => story.togglePause());
    $("#btn-back").addEventListener("click", () => story.back());
    $("#btn-next").addEventListener("click", () => story.next());
    $("#btn-music").addEventListener("click", () => player.toggle());
    $("#btn-mute").addEventListener("click", () => player.toggleMute());

    document.addEventListener("keydown", (event) => {
      if (!story.started || event.target.closest("input, textarea, select")) return;
      if (event.key === "ArrowRight") story.next();
      else if (event.key === "ArrowLeft") story.back();
      else if (event.key === " " && !event.target.closest("button, a, label")) {
        event.preventDefault();
        story.togglePause();
      }
    });
  }

  async function boot() {
    setupLoginForm();
    setupControls();
    setupParallax();
    try {
      const { authenticated } = await refreshSession();
      if (authenticated) {
        await enterEnvelope();
        return;
      }
    } catch {
      toast("Server belum bisa dihubungi. Coba muat ulang halamannya ya.", "error");
    }
    showLogin();
  }

  boot();
})();
