/*
 * npm run set-login
 * Mengganti username dan password login. Password disimpan sebagai hash bcrypt
 * di file .env. SESSION_SECRET dibuat otomatis kalau belum ada.
 */
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const readline = require("readline");
const bcrypt = require("bcrypt");

const ENV_FILE = path.join(__dirname, "..", ".env");

function setValue(content, key, value) {
  const line = `${key}='${value}'`;
  const pattern = new RegExp(`^${key}=.*$`, "m");
  // Pakai fungsi agar karakter $ pada hash tidak dibaca sebagai pola pengganti.
  return pattern.test(content) ? content.replace(pattern, () => line) : `${content.trimEnd()}\n${line}\n`;
}

async function main() {
  const rl = readline.createInterface({ input: process.stdin });
  const lines = rl[Symbol.asyncIterator]();
  const ask = async (label) => {
    process.stdout.write(label);
    const { value } = await lines.next();
    return (value || "").trim();
  };

  const username = await ask("Username baru: ");
  const password = await ask("Password baru (minimal 8 karakter): ");
  rl.close();

  if (!username || password.length < 8) {
    console.error("\nUsername wajib diisi dan password minimal 8 karakter. Tidak ada yang diubah.");
    process.exit(1);
  }

  let env = fs.existsSync(ENV_FILE)
    ? fs.readFileSync(ENV_FILE, "utf8")
    : "PORT=3000\nNODE_ENV=development\nTIMEZONE=Asia/Jakarta\n";

  env = setValue(env, "LOGIN_USERNAME", username);
  env = setValue(env, "LOGIN_PASSWORD_HASH", await bcrypt.hash(password, 12));
  if (!/^SESSION_SECRET=.{32,}$/m.test(env)) {
    env = setValue(env, "SESSION_SECRET", crypto.randomBytes(48).toString("hex"));
  }

  fs.writeFileSync(ENV_FILE, env, { mode: 0o600 });
  console.log("\nSelesai. Restart server (npm start) supaya login baru berlaku.");
}

main().catch((error) => {
  console.error(error.message);
  process.exit(1);
});
